package controller;

public class AAA_SOFTWARE_EINSTELLUNGEN {
	
	/*
	 * Einstellungsseite zum erleichtern der Arbeit bei Entwicklung
	 */
	
	public boolean rootmode() { //rootmodus (+autologin, +bildschirm positionierung)
		return false;
	}
	
	public boolean operatorframe() { //operator fenster
		return true;
	}
	
	public boolean skipstarter() { //online/offline anfrage bei start, bei deaktivierung wird der online modus standartmäßig aktiviert
		return false;
	}
}
