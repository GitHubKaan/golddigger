package controller;

public class Printer {
	public void setLog(String p) {
		System.out.println("[ OK ] " + p);
	}
	public void setNoLineLog(String p) {
		System.out.print("[ OK ] " + p);
	}
	public void setErrLog(String e) {
		System.err.println("[ FEHLER ] " + e);
	}
	public void setActionLog(String e) {
		System.out.println("[ EVENT ] " + e);
	}
}
