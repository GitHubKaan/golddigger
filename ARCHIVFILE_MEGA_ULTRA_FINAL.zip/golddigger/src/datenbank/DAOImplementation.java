package datenbank;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DAOImplementation implements DAO {
	
	/*
	 * sql anfragen werden von hier aus verschickt
	 */
	
	static int currentPunkte; //temporärer punkte speicher
	static String currentUsername; //temporärer benutzername speicher
	static String currentPassword; //temporärer passowrd speicher
	
	//benutzer hinzufügen
	@Override
	public void addUser(User user) {
		OracleDsSingleton ora = OracleDsSingleton.getInstance();
		try {
			Connection con = ora.getConnection();
			String sql = "insert into golddigger values (?, ?, ?)"; //benutzername, passwort, punkte
			
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, user.getBenutzername());
			ps.setString(2, user.getPasswort());
			ps.setInt(3, user.getPoints());
			ps.executeUpdate();

		} catch (SQLException e) {
		}
	}
	
	//benutzer bearbeiten (aktuell werden nur punkte manipuliert)
	@Override
	public void editUser(User user) {
		OracleDsSingleton ora = OracleDsSingleton.getInstance();
		try {
			Connection con = ora.getConnection();
			String sql = ("update golddigger set punkte=punkte+? where name=?"); //punkte addition (es kann auch negativ addiert werden)
				
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setInt(1, user.getPoints());
			ps.setString(2, user.getBenutzername());
			ps.executeUpdate();
				
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	//benutzer löschung
	@Override
	public void deleteUser(User user) {
		OracleDsSingleton ora = OracleDsSingleton.getInstance();
		try {
			Connection con = ora.getConnection();
			String sql = ("delete from golddigger where name = ?"); //primarykey: name
			
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, user.getBenutzername());
			ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	//benutzerdaten abfrage (name, passwort für login bsp. und punkte für startseite bsp.)
	@Override
	public boolean getUser(User user) {
		OracleDsSingleton ora = OracleDsSingleton.getInstance();
		try {
			Connection con = ora.getConnection();
			Statement stmt = con.createStatement();
			String addQuery = "select * from golddigger where name = '" + user.getBenutzername() + "' and passwort = '" + user.getPasswort() + "'";
			ResultSet rs = stmt.executeQuery(addQuery);
			
			currentUsername = user.getBenutzername();
			currentPassword = user.getPasswort();
			
			while (rs.next()) {
				
				try {
					User user_class = new User();
					user_class.setPoints(rs.getInt("punkte"));
					
					currentPunkte = user_class.getPoints();
				} catch (IOException e1) {
					e1.printStackTrace();
				}
				return true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}
	
	//wiedergabe temporär gespeicherter punkte
	public int getCurrentPunkte() {
		return currentPunkte;
	}
	
	//wiedergabe temporär gespeicherter benutzername
	public String getCurrentUsername() {
		return currentUsername;
	}
	
	//wiedergabe temporär gespeicherter passwort
	public String getCurrentPassword() {
		return currentPassword;
	}
}
