package controller;

public class Einstellungen {
	public boolean rootmode() { //Root-Modus (autologin, bildschirm location)
		return false;
	}
	
	public boolean adminpanel() { //adminpanel aktivieren/deaktivieren
		return true;
	}
	
	public boolean skipstarter() { //okay window am anfang
		return false;
	}
}
