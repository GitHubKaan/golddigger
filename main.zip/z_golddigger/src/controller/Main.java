package controller;

import java.io.IOException;
import java.sql.SQLException;

import ui.Fehleranzeige;

public class Main {
	public static void main(String[] args) throws IOException {
		System.out.println("hwrpb_system startet...");
		System.out.println("\n"
						 + "Name: HWR-Payback\n"
						 + "	|_ Main: " + Main.class + "\n"
						 + "	|_ Version: 0.0.1" + "\n"
						 + "Entwickler: kaan, natasza, furkan, nurdan\n"
						 + "	|_ Semester: WS 2021/22\n"
						 + "	|_ Universit�t: Hochschule f�r Wirtschaft und Recht Berlin - Campus Sch�neberg\n"
						 + "	|_ Kurs: 315202 Objektorientierte Programmierung II (Gruppe 02)\n"
						 + "	|_ Dozent: Prof. Dr. Markus Schaal\n");
		
		System.out.println(Main.class + " -> abruf");
		
		new Fehleranzeige();
	}
}
