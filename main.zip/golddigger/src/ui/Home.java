package ui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.net.URL;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.Timer;

import db.DAOImplementation;
import db.User;
import controller.Clicker;
import controller.AAA_SOFTWARE_EINSTELLUNGEN;
import controller.Fonts;
import controller.Frame;
import controller.Main;
import controller.Offline;
import controller.Printer;

public class Home implements ActionListener {
	
	JPanel[] panels = new JPanel[100];
	JLabel[] labels = new JLabel[100]; 
	JButton[] buttons = new JButton[100];
	
	User user_class = new User();
	Settings settings_class = new Settings();
	Help help_class = new Help();
	Shop shop_class = new Shop();
	Printer printer_class = new Printer();
	Frame frame_class = new Frame();
	Fonts fonts_class = new Fonts();
	DAOImplementation dao_class = new DAOImplementation();
	Clicker ce_class = new Clicker();
	AAA_SOFTWARE_EINSTELLUNGEN einst_class = new AAA_SOFTWARE_EINSTELLUNGEN();
	
	JFrame frame = new JFrame();
	JButton clicker = new JButton();
	Timer timer;
	
	public Home() throws IOException {
		
		for (int i = 0; i < 100; i++) {
		    panels[i] = new JPanel();
			labels[i] = new JLabel();
			buttons[i] = new JButton();
		}
		
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(400, 800);
		frame.setTitle("Gold Digger - Home");
		frame.setResizable(false);
		frame.setLocation(frame_class.getLetzteFramePosition());
		
		URL icon_image_url = getClass().getResource("/textures/extra/icon.png");
		ImageIcon icon = new ImageIcon(icon_image_url);
		frame.setIconImage(icon.getImage());
		
		frame.add(settings_class);
		frame.add(help_class);
		frame.add(shop_class);
		
		for (int i = 0; i < panels.length; i++) {
		    panels[i].setOpaque(false);
		    panels[i].setLayout(new BorderLayout(0, 0));
		}
		
		panels[1].setBounds(349, 5, 30, 30);
		panels[2].setBounds(30, 134, 385, 79);
		panels[3].setBounds(10, 672, 80, 80);
		panels[4].setBounds(316, 5, 30, 30);
		panels[5].setBounds(10, 10, 35, 35);
		
		for (int i = 1; i < 6; i++) {
			if (i != 2) {
				panels[i].add(buttons[i - 1]);
			}
		}
		
		for (int i = 0; i < buttons.length; i++) {
			buttons[i].setOpaque(false);
			buttons[i].setContentAreaFilled(false);
			buttons[i].setBorderPainted(false);
			
			buttons[i].addActionListener(this);
		}
		
		
		//token anzeige
		labels[1].setFont(fonts_class.getFont2());
		
		validierung();
		
		panels[6].setBounds(40, 8, 288, 30);
		panels[6].add(labels[1]);
		
		
		
		for (int i = 0; i < panels.length; i++) {
			frame.add(panels[i]);
		}
		
		
		labels[0].setBounds(0, 0, 385, 761);
		
		URL image_url = Main.class.getResource("/textures/background/home.png");
		
		BufferedImage image = null;
		try {
			image = ImageIO.read(image_url);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		Image scaled_image = image.getScaledInstance(labels[0].getWidth(), labels[0].getHeight(), Image.SCALE_REPLICATE);
		
		ImageIcon bgimage = new ImageIcon(scaled_image);
		
		labels[0].setIcon(bgimage);
		labels[0].setBounds(0, 0, 385, 761);
				
		
		//clicker
		int clicker_size = 250;
		
		JPanel clicker_panel = new JPanel();
		  
		clicker.setLocation(0, 0);
		clicker.setVisible(true);
		clicker.setBackground(Color.BLACK);
		clicker.setOpaque(true);
		clicker.setBorderPainted(false);
		clicker.setFocusable(false);
		clicker.setRolloverEnabled(false);
		clicker.setLayout(new BorderLayout(0, 0));
		
		try {
			Image img = null;
			
			if (ce_class.getObjekt() == 0) {
				 img = ImageIO.read(getClass().getResource("/textures/background/stone.png"));
			} else if (ce_class.getObjekt() == 1) {
				img = ImageIO.read(getClass().getResource("/textures/background/diamond.png"));
			} else if (ce_class.getObjekt() == 2) {
				img = ImageIO.read(getClass().getResource("/textures/background/smaragd.png"));
			} else if (ce_class.getObjekt() == 3) {
				img = ImageIO.read(getClass().getResource("/textures/background/gold.png"));
			}
			
			clicker.setIcon(new ImageIcon(img));
			
		} catch (Exception ex) {}
		
		clicker_panel.setLayout(null);
		clicker_panel.setLayout(new BorderLayout(0, 0));
		clicker_panel.setBounds(68, 260, clicker_size, clicker_size);
		
		clicker_panel.add(clicker);
		frame.add(clicker_panel);
		
		clicker.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				clicker.setBackground(new Color(0f, 0f, 0f, 0f));
				
				ce_class.clickercclick();
				
				if (Clicker.objekt == 0) {
					Clicker.ani_count += 1;
				} else if (Clicker.objekt == 1) {
					Clicker.ani_count += 2;
				} else if (Clicker.objekt == 2) {
					Clicker.ani_count += 1000;
				} else if (Clicker.objekt == 3) {
					Clicker.ani_count += 100000;
				}
				
				if (Offline.getOfflineMode() == true) {
					Clicker.ani_count -= Clicker.ani_count/2 + 1;
				}
				
				labels[1].setFont(new Font("Calibri", Font.BOLD, 18));
				if (Offline.getOfflineMode() == false) {
					labels[1].setText(Integer.toString(dao_class.getCurrentPunkte() + Clicker.ani_count) + " Gold");
				} else {
					labels[1].setText(Integer.toString(Offline.getPunkte() + Clicker.ani_count) + " Gold");
				}
				
				clicker.setEnabled(false);
				clicker.setVisible(false);
				

				//animation der punkteanzeige
				timer = new Timer(10, new ActionListener() { 
					@Override
					public void actionPerformed(ActionEvent e) {
						if (Clicker.label_animation > 10) {
							printer_class.setLog("abbruch animation");
							timer.stop();
							
							clicker.setEnabled(true);
							clicker.setVisible(true);
						}
						Clicker.label_animation+=1;
						
						animation();
					}
				});
				if (!timer.isRunning()) {
					timer.start(); //startet timer
				}
				
				Clicker.label_animation=0;
			}
		});
		
		
		frame.add(labels[0]);
		
		frame.setVisible(true);
		
		//abmelden
		settings_class.buttons[1].addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				
				if (einst_class.rootmode() == false) {
					if (Offline.getOfflineMode() == false) {
						int rückzahlung = 0;
						
						User currentUser = new User(dao_class.getCurrentUsername(), dao_class.getCurrentPassword(), 0);
						dao_class.getUser(currentUser);
						
						if (ce_class.getObjekt() == 1) { //rückzahlung für diamand
							rückzahlung = 5;
						} else if (ce_class.getObjekt() == 2) { //rückzahlung für smaragd
							rückzahlung = 30;
						} else if (ce_class.getObjekt() == 3) { //rückzahlung für gold
							rückzahlung = 10000;
						}
						
						User tokenUser = new User(dao_class.getCurrentUsername(), "", rückzahlung);
						dao_class.editUser(tokenUser);
					}
					
					ce_class.setObjekt(0);
					
					frame.setVisible(false);
					
					frame_class.setFramePosition(frame.getLocation());
					
					try {
						new Login();
					} catch (IOException e1) {
						e1.printStackTrace();
					}
					
					printer_class.setLog("Benutzer wird abgemeldet...");
				} else {
					JOptionPane.showMessageDialog(frame, "Du kannst dich im Rootmodus nicht abmelden.");
				}
				
			}
		});
	}
	
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == buttons[0]) { //Einstellungen
			settings_class.setVisible(true);
			homeClose();
		}
		
		if (e.getSource() == buttons[2]) { //Shop
			Clicker.ani_count = 0;
			validierung();
			shop_class.setVisible(true);
			homeClose();
		}
		
		if (e.getSource() == buttons[3]) { //Hilfe
			help_class.setVisible(true);;
			homeClose();
		}
		
		//zurück button, schaltet auf home zurück
		if (e.getSource() == buttons[4]) {
			settings_class.setVisible(false);
			help_class.setVisible(false);
			shop_class.setVisible(false);
			
			settings_class.previousPage();
			
			validierung();
			
			homeOpen();
		}
	}
	
	private void homeOpen() {
		for (int i = 0; i < buttons.length; i++) {
			buttons[i].setVisible(true);
		}
	}
	
	private void homeClose() {
		for (int i = 0; i < buttons.length; i++) {
			if (i != 4) {
				buttons[i].setVisible(false);
			}
		}
	}
	
	//validierung der punkte
	private void validierung() {
		if (Offline.getOfflineMode() == false) {
			User currentUser = new User(dao_class.getCurrentUsername(), dao_class.getCurrentPassword(), 0);
			dao_class.getUser(currentUser);
		
			Integer currentTokens = dao_class.getCurrentPunkte();
		
			if (currentTokens >= 0 && currentTokens < 10000000) {
				labels[1].setForeground(Color.BLACK);
				labels[1].setText(currentTokens.toString() + " Gold");
			} else {
				labels[1].setText("FEHLER");
			
				if (currentTokens < 0) {
					User tokenUser = new User(dao_class.getCurrentUsername(), "", -1*currentTokens);
					dao_class.editUser(tokenUser);
				} else {
					User tokenUser = new User(dao_class.getCurrentUsername(), "", -currentTokens);
					dao_class.editUser(tokenUser);
				}
			}
		} else {
			if (Offline.getPunkte() >= 0 && Offline.getPunkte() < 10000000) {
				labels[1].setForeground(Color.BLACK);
				labels[1].setText(Offline.getPunkte() + " Gold");
			} else {
				labels[1].setText("FEHLER");
			
				if (Offline.getPunkte() < 0) {
					Offline.setPunkte(-1*Offline.getPunkte());
				} else {
					Offline.setPunkte(-Offline.getPunkte());
				}
			}
		}
		
		labels[1].setFont(new Font("Calibri", Font.BOLD, 19));
		
		try {
			Image img = null;
			
			if (ce_class.getObjekt() == 0) {
				 img = ImageIO.read(getClass().getResource("/textures/background/stone.png"));
			} else if (ce_class.getObjekt() == 1) {
				img = ImageIO.read(getClass().getResource("/textures/background/diamond.png"));
			} else if (ce_class.getObjekt() == 2) {
				img = ImageIO.read(getClass().getResource("/textures/background/smaragd.png"));
			} else if (ce_class.getObjekt() == 3) {
				img = ImageIO.read(getClass().getResource("/textures/background/gold.png"));
			}
			
			clicker.setIcon(new ImageIcon(img));
			
		} catch (Exception ex) {}
	}
	
	private void animation() {
		labels[1].setFont(new Font("Calibri", Font.BOLD, 5 + Clicker.label_animation));
		frame.repaint();
	}
}
