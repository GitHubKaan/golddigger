package controller;

import db.DAOImplementation;

public class ClickerEvent {
	
	DAOImplementation dao_class = new DAOImplementation();
	
	public static int label_animation = 0;
	public static int ani_count = 0;
	
	public static int Objekt = 0;
	
	public void clickercclick() {
		User tokenUser = null;
		
		if (OfflineMode.getOfflineMode() == false) {
			if (Objekt == 1) { //diamand
				tokenUser = new User(dao_class.getCurrentUsername(), "", +2);
			} else if (Objekt == 2) { //smaragd
				tokenUser = new User(dao_class.getCurrentUsername(), "", +1000);
			} else if (Objekt == 3) { //gold
				tokenUser = new User(dao_class.getCurrentUsername(), "", +100000);
			} else { //stone
				tokenUser = new User(dao_class.getCurrentUsername(), "", +1);
			}
			
			dao_class.editUser(tokenUser);
		} else {
			if (Objekt == 1) { //diamand
				OfflineMode.setPunkte(2);
			} else if (Objekt == 2) { //smaragd
				OfflineMode.setPunkte(1000);
			} else if (Objekt == 3) { //gold
				OfflineMode.setPunkte(100000);
			} else { //stone
				OfflineMode.setPunkte(1);
			}
		}
	};
	
	public void setObjekt(int i) {
		Objekt = i;
	}
	
	public int getObjekt() {
		return Objekt;
	}
}
