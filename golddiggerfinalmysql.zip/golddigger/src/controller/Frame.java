package controller;

import java.awt.Point;

public class Frame {
	
	Printer printer_class = new Printer();
	
	static Point frame_location;
	
	public void setFramePosition(Point l) { //letzte frame position speichern
		frame_location = l;
	}
	public Point getLetzteFramePosition() { //letzte frame position abrufen
		return frame_location;
	}
}
