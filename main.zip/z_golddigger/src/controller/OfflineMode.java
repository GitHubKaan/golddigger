package controller;

public class OfflineMode {
	
	public static boolean offline_modus = false;
	public static int punkte = 0;
	
	public static boolean getOfflineMode() {
		return offline_modus;
	}
	public static int getPunkte() {
		return punkte;
	}
	public static void setPunkte(int i) {
		System.out.println("+ punkte");
		punkte += i;
	}
}
