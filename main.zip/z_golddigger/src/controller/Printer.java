package controller;

public class Printer {
	public void printLog(String p) {
		System.out.println("[ OK ] " + p);
	}
	
	public void printNoLineLog(String p) {
		System.out.print("[ OK ] " + p);
	}
	
	public void errLog(String e) {
		System.err.println("[ FEHLER ] " + e);
	}
	
	public void actionLog(String e) {
		System.out.println("[ EVENT ] " + e);
	}
}
