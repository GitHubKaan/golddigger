package controller;

public class Offline {
	
	/*
	 * dies klasse ist ausschließlich für den offlinemodus relevant
	 */
	
	public static boolean offline_modus = false;
	public static int punkte = 0;
	
	public static boolean getOfflineMode() { //offlinemodus wird hier abgefragt
		return offline_modus;
	}
	
	public static int getPunkte() { //punkte abfrage für offlinemodus
		return punkte;
	}
	public static void setPunkte(int i) { //punkte anpassen für offlinemodus
		punkte += i;
	}
}
