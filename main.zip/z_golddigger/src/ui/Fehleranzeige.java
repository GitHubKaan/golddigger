package ui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import controller.Admin;
import controller.Einstellungen;
import controller.Fonts;

public class Fehleranzeige {
	
	public boolean mode = false; //in bearbeitung
	
	
	public Fehleranzeige() {
		
		Einstellungen einst = new Einstellungen();
		
		String status = "";
		
		
		
		
		Fonts font_class = null;
		try {
			font_class = new Fonts();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		
		JFrame frame = new JFrame();
		frame.setUndecorated(true);
		frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		frame.setSize(400, 150);
		frame.setLocationRelativeTo(null);
		frame.setResizable(false);
		frame.setAlwaysOnTop(true);
		frame.getContentPane().setBackground(Color.WHITE);
		frame.setLayout(new BorderLayout(0, 0));
		
		JPanel bbackground = new JPanel();
		bbackground.setLayout(null);
		bbackground.setVisible(true);
		bbackground.setBounds(150, 110, 90, 35);
		bbackground.setBackground(Color.BLACK);
		bbackground.setLayout(new BorderLayout(0, 0));
		
		JPanel bbackground2 = new JPanel();
		bbackground2.setVisible(true);
		bbackground2.setBackground(Color.WHITE);
		bbackground2.setLayout(null);
		
		JButton okbutton = new JButton();
		okbutton.setVisible(true);
		okbutton.setOpaque(false);
		okbutton.setContentAreaFilled(false);
		okbutton.setBorderPainted(false);
		
		JLabel buttontext = new JLabel();
		buttontext.setText("<html><b>okay</b></html>");
		buttontext.setForeground(Color.WHITE);
		buttontext.setBounds(0, 0, 100, 100);
		buttontext.setVisible(true);
		buttontext.setFont(font_class.getFontTypeA());
		
		if (mode == true && einst.rootmode() == false) {
			status = "good";
		} else {
			status = "not good";
		}
		
		JLabel information = new JLabel();
		information.setFont(font_class.getFontTypeA());
		information.setText("<html><b>info</b><br/>"
								+ "online-mode: " + mode + "<br/>"
								+ "root-mode: " + einst.rootmode() + "<br/>"
								+ "general-status: " + status + "<br/><br/></html>");
		information.setForeground(Color.BLACK);
		information.setBounds(15, 15, 300, 100);
		information.setVisible(true);
		
		bbackground2.add(bbackground);
		okbutton.add(buttontext);
		bbackground.add(okbutton);
		
		frame.add(bbackground2);
		bbackground2.add(information);
		
		
		
		
		
		if (einst.skipstarter() == true) {
			System.out.println("ok");
			frame.setVisible(false);
			frame.setEnabled(false);
			
			
			
			
			try {
				new Admin();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		} else {
			frame.setVisible(true);
		}
		
		
		
		
		
		
		
		
		
		okbutton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				System.out.println("ok");
				frame.setVisible(false);
				frame.setEnabled(false);
				
				
				
				
				try {
					new Admin();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
	}
}
