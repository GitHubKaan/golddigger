package ui;

import java.awt.BorderLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.net.URL;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

import controller.Fonts;
import controller.Main;
import controller.Offline;
import datenbank.DAOImplementation;
import datenbank.User;

public class Einstellungen extends JPanel implements ActionListener {
	
	/*
	 * Einstellungsmenü
	 */
	
	JButton[] buttons = new JButton[100];
	JPanel[] panels = new JPanel[100];
	JLabel[] labels = new JLabel[100];
	
	User user_class = new User();
	Fonts fonts_class = new Fonts();
	DAOImplementation dao_class = new DAOImplementation();
	
	public Einstellungen() throws IOException {
		
		for (int i = 0; i < 100; i++) {
		    panels[i] = new JPanel();
			buttons[i] = new JButton();
			labels[i] = new JLabel();
		}
		
		setBounds(0, 0, 400, 800);
		setVisible(false);
		setLayout(null);
		
		for (int i = 0; i < panels.length; i++) {
		    panels[i].setOpaque(false);
		}
		
		buttons[2].setVisible(false); 
		panels[5].setVisible(false);
				
		panels[0].setBounds(10, 64, 79, 79);
		panels[1].setBounds(98, 64, 79, 79);
		panels[2].setBounds(52, 10, 35, 35);
		
		for (int i = 0; i < 3; i++) {
			buttons[i].setOpaque(false);
			buttons[i].setContentAreaFilled(false);
			buttons[i].setBorderPainted(false);
			
			buttons[i].addActionListener(this);
			
			buttons[i].setFocusable(false);
			
			panels[i].setLayout(new BorderLayout(0, 0));
			panels[i].add(buttons[i]);
		}
		
		//hintergrund
		panels[4].setBounds(0, 0, 385, 761);
		panels[4].setLayout(null);
		
		labels[1].setBounds(0, 0, 385, 761);
		
		URL image_url = Main.class.getResource("/textures/background/settings.png");
		
		BufferedImage image = null;
		try { //Bild Import
			image = ImageIO.read(image_url);
		} catch (IOException e) {
		    e.printStackTrace();
		}
		
		Image scaled_image = image.getScaledInstance(labels[1].getWidth(), labels[1].getHeight(), Image.SCALE_REPLICATE);
		
		ImageIcon bgimage = new ImageIcon(scaled_image);
		
		labels[1].setIcon(bgimage);
		
		panels[4].add(labels[1]);
		
		for (int i = 0; i < panels.length; i++) {
			add(panels[i]);
		}
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		
		if (e.getSource() == buttons[0]) {
			nextPage();
			
			if (Offline.getOfflineMode() == false) { //text bei online modus mit datenabankanbindung
				labels[0].setText("<html><b>Benutzername:</b> " + dao_class.getCurrentUsername() + "<br/>" +
						  "<b>Passwort:</b> " + dao_class.getCurrentPassword() + "<br/>" +
						  "<b>Token:</b> " + dao_class.getCurrentPunkte() + "<br/><br/>" +
						  "Software: Gold Digger<br/>" +
						  "Entwickler: F. Adigüzel, K. Turan<br/>" +
						  "Version: 1.0<br/>" +
						  "Java Version: JavaSE-17<br/>" +
						  "Datenbank Typ: MySQL<br/><br/>" +
						  
						  "Modus: Online<br/>" +
						  "</html>");
				
				System.out.println("text für online modus aktiviert");
			} else { //text bei offline modus ohne datenbankanwendung
				labels[0].setText("<html><b>Benutzername:</b> offline modus<br/>" +
						  "<b>Passwort:</b> offline modus<br/>" +
						  "<b>Token:</b> " + Offline.getPunkte() + "<br/><br/>" +
						  "Software: Gold Digger<br/>" +
						  "Entwickler: F. Adigüzel, K. Turan<br/>" +
						  "Version: 1.0<br/>" +
						  "Java Version: JavaSE-17<br/><br/>" +
						  "Datenbank Typ: MySQL<br/><br/>" +
						  
						  "Modus: Offline<br/>" +
						  "</html>");
				
				System.out.println("text für offline modus aktiviert");
			}
			
			labels[0].setBounds(40, 70, 300, 350);
			labels[0].setFont(fonts_class.getFont1());
			
			panels[3].setBounds(0, 0, 385, 761);
			panels[3].setLayout(null);
			
			panels[3].add(labels[0]);
			
			panels[5].setBounds(0, 0, 385, 761);
			panels[5].setLayout(null);
			
			labels[2].setBounds(0, 0, 385, 761);
			
			URL image_url = Main.class.getResource("/textures/background/settings_info.png");
			
			BufferedImage image = null;
			try {
				image = ImageIO.read(image_url);
			} catch (IOException e1) {
			    e1.printStackTrace();
			}
			
			Image scaled_image = image.getScaledInstance(labels[2].getWidth(), labels[2].getHeight(), Image.SCALE_REPLICATE); //passt das Bild der Gr��e des JLabels an, "SCALE_REPLICATE" ist die Art wir die Pixel gescaled und Verarbeitet werden
			
			ImageIcon bgimage = new ImageIcon(scaled_image);
			
			labels[2].setIcon(bgimage);
			
			panels[5].add(labels[2]);
		}
		
		if (e.getSource() == buttons[2]) {
			previousPage();
		}
	}

	private void nextPage() {
		System.out.println("zweite seite im einstellungsmenü geöffnet");
		
		panels[4].setVisible(false);
		panels[5].setVisible(true);
		
		buttons[0].setVisible(false);
		buttons[1].setVisible(false);
		
		buttons[2].setVisible(true);
		
		panels[3].setVisible(true);
		
		repaint();
	}
	
	public void previousPage() {
		System.out.println("erste seite im einstellungsmenü geöffnet");
		
		panels[4].setVisible(true);
		panels[5].setVisible(false);
		
		buttons[0].setVisible(true);
		buttons[1].setVisible(true);
		
		buttons[2].setVisible(false);
		
		panels[3].setVisible(false);
		
		repaint();
	}
}
