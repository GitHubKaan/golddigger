package controller;

import java.awt.Font;
import java.io.IOException;

public class Fonts {
	Printer printer_class = new Printer();

	
	public Fonts() throws IOException {
		printer_class.printLog(Fonts.class + " -> abruf");
	}

	
	public Font getFontTypeA() {
		return new Font("Arial", Font.PLAIN, 16);
	}

	public Font getFontTypeB() {
		return new Font("Calibri", Font.BOLD, 30);
	}

	public Font getFontTypeC() {
		return new Font("Calibri", Font.BOLD, 18);
	}
	
	public Font getFontTypeD() {
		return new Font("Calibri", Font.BOLD, 19);
	}
}
