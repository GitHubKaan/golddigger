package datenbank;

import java.io.IOException;

public class User {
	
	String name;
	String passwort;
	int punkte;
	
	/*
	 * set-/get benutzerdaten durch dao
	 */
	
	public User() throws IOException {}
	
	public User(String benutzername, String passwort, int tokens) {
		this.name = benutzername;
		this.passwort = passwort;
		this.punkte = tokens;
	}
	
	public String getBenutzername() {
		return name;
	}

	public void setBenutzername(String benutzername) {
		this.name = benutzername;
	}

	public String getPasswort() {
		return passwort;
	}

	public void setPasswort(String passwort) {
		this.passwort = passwort;
	}

	public int getPoints() {
		return punkte;
	}

	public void setPoints(int t) {
		this.punkte = t;
	}
}
