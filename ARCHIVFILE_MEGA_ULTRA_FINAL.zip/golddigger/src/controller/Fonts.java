package controller;

import java.awt.Font;

public class Fonts {
	
	/*
	 * hier werden die Schriftarten abgefragt
	 */
	
	public Font getFont1() {
		return new Font("Arial", Font.PLAIN, 16);
	}
	public Font getFont2() {
		return new Font("Calibri", Font.BOLD, 19);
	}
}
