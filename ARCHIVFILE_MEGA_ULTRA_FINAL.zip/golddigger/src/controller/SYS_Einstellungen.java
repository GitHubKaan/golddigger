package controller;

public class SYS_Einstellungen {
	
	/*
	 * einstellungsseite zum erleichtern der arbeit bei entwicklung
	 * (kann nach abschluss der programmierung gelöscht werden)
	 */
	
	public boolean rootmode() { //ermöglicht: +autologin, +individuelle bildschirm positionierung	
		return false;
	}
	
	public boolean operatorframe() { //öffnet ein fenster beim online-modus zum manipulieren der datenbankeinträge
		return true;
	}
	
	public boolean skipstarter() { //startfenster mit auswahl zwischen online/offline-modus, bei deaktivierung wird der onlin-modus standartmäßig gestartet
		return false;
	}
}
