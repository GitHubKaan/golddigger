package db;

import java.sql.*;
import oracle.jdbc.pool.OracleDataSource;
import ui.Fehleranzeige;

public class OracleDsSingleton {
	
	private static OracleDsSingleton dss = null;
	private static OracleDataSource ds = null;
	
	private OracleDsSingleton(){
		
		try {
			ds = new OracleDataSource();
			
			ds.setDataSourceName("x");
			ds.setURL("x");
			
			ds.setUser("x");
			ds.setPassword("x");

		} catch (SQLException e) {
			e.printStackTrace();
			System.err.println("keine verbindung zum server möglich");
		}
	}
	
	
	public static OracleDsSingleton getInstance() {
		if(dss == null) dss = new OracleDsSingleton();
		return dss;
	}
	
	public Connection getConnection() throws SQLException{
		Connection con = null;
		con = ds.getConnection();
		return con;
	}
}
