package db;

import java.sql.*;

import com.mysql.cj.jdbc.MysqlDataSource;

public class OracleDsSingleton {
	
	private static OracleDsSingleton dss = null;
	private static MysqlDataSource ds = null;
	
	private OracleDsSingleton(){
		ds = new MysqlDataSource();
		
		ds.setURL("jdbc:mysql://localhost:3306/sqlprojname");
		ds.setUser("username");
		ds.setPassword("password");
	}
	
	public static OracleDsSingleton getInstance() {
		if(dss == null) dss = new OracleDsSingleton();
		return dss;
	}
	
	public Connection getConnection() throws SQLException{
		Connection con = null;
		con = ds.getConnection();
		return con;
	}
}
