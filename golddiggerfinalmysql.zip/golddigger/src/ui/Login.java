package ui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.net.URL;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import db.DAOImplementation;
import db.User;
import controller.AAA_SOFTWARE_EINSTELLUNGEN;
import controller.Fonts;
import controller.Frame;
import controller.Main;
import controller.Offline;
import controller.Printer;

public class Login {
	
	JPanel[] panels = new JPanel[100];
	JLabel[] labels = new JLabel[100]; 
	JButton[] buttons = new JButton[100];
	JTextField[] textfields = new JTextField[100];
	JPasswordField[] passwordfields = new JPasswordField[100];
	
	static int wrong_password_counter = 0;
	
	User user_class = new User();
	Printer printer_class = new Printer();
	Frame frame_class = new Frame();
	Fonts fonts_class = new Fonts();
	AAA_SOFTWARE_EINSTELLUNGEN eins_class = new AAA_SOFTWARE_EINSTELLUNGEN();
	
	public Login() throws IOException {
		
		printer_class.setLog(Login.class + " -> abruf");
		
		
		for (int i = 0; i < 100; i++) {
		    panels[i] = new JPanel();
			labels[i] = new JLabel();
			buttons[i] = new JButton();
			textfields[i] = new JTextField();
			passwordfields[i] = new JPasswordField();
		}
		
		JFrame frame = new JFrame();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(400, 800);
		
		if (frame_class.getLetzteFramePosition() == null) {
			if (eins_class.rootmode() == true) {
				frame.setLocation(-450, 500);
			} else {
				frame.setLocationRelativeTo(null);
			}
		} else {
			frame.setLocation(frame_class.getLetzteFramePosition());
		}
		
		frame.setTitle("Gold Digger - Login");
		frame.setLayout(null);
		frame.setResizable(false);
		
		URL icon_image_url = getClass().getResource("/textures/extra/icon.png");
		ImageIcon icon = new ImageIcon(icon_image_url);
		frame.setIconImage(icon.getImage());
		
		
		for (int i = 0; i < panels.length; i++) {
		    panels[i].setOpaque(false);
		    panels[i].setLayout(new BorderLayout(0, 0));
		}
		
		//accountname
		textfields[0].setFont(fonts_class.getFont1());
		
		panels[1].setBounds(35, 390, 315, 45);
		panels[1].add(textfields[0]);
		
		frame.add(panels[1]);
		
		//passwortfeld
		passwordfields[0].setFont(fonts_class.getFont1());
		
		panels[2].setBounds(35, 441, 315, 45);
		panels[2].add(passwordfields[0]);
		
		frame.add(panels[2]);
		
		//anmeldebutton
		buttons[0].setOpaque(false);
		buttons[0].setContentAreaFilled(false);
		buttons[0].setBorderPainted(false);
		
		panels[3].setBounds(120, 500, 145, 45);
		panels[3].add(buttons[0]);
		
		frame.add(panels[3]);
		
		//hintergrundsebene
		labels[0].setBounds(0, 0, 385, 761);
		
		URL image_url = Main.class.getResource("/textures/background/login.png");
		
		BufferedImage image = null;
		try {
			image = ImageIO.read(image_url);
		} catch (IOException e) {
		    e.printStackTrace();
		}
		
		Image scaled_image = image.getScaledInstance(labels[0].getWidth(), labels[0].getHeight(), Image.SCALE_REPLICATE);
		
		ImageIcon bgimage = new ImageIcon(scaled_image);
		
		labels[0].setIcon(bgimage);
		
		frame.add(labels[0]);
		
		
		frame.setVisible(true);
		
		textfields[0].addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				passwordfields[0].requestFocus();
			}
		});
		
		passwordfields[0].addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				buttons[0].doClick();
			}
		});
		
		buttons[0].addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				
				if (Offline.getOfflineMode() == true) { 
					frame_class.setFramePosition(frame.getLocation()); 
					frame.setVisible(false);
					wrong_password_counter = 0; 
					
					try {
						new Home();
					} catch (IOException e2) {}
				} else {
					
					//anmelden
					DAOImplementation dao = new DAOImplementation();
					
					User currentUser = new User(textfields[0].getText(), passwordfields[0].getText(), 0);
					
					if (dao.getUser(currentUser) == true) {
						printer_class.setLog("Login erfolgreich");
						
						//passwort richtig
						printer_class.setLog("Passwort korrekt");
						
						frame_class.setFramePosition(frame.getLocation());
						
						frame.setVisible(false);
						
						wrong_password_counter = 0;
						
						try {
							new Home();
						} catch (IOException e2) {}
						
					} else {
						printer_class.setErrLog("Login nicht erfolgreich");
						
						//passwort falsch
						printer_class.setErrLog("Passwort inkorrekt");
						
						Color loginWrong = new Color(255, 177, 177);
						textfields[0].setBackground(loginWrong);
						passwordfields[0].setBackground(loginWrong);
						
						wrong_password_counter++;
						
						textfields[0].requestFocus();
						
						printer_class.setLog("Falsches Passwort (Versuch): " + wrong_password_counter + "/10");
						
						//was in beiden fällen passiert
						passwordfields[0].setText("");
						textfields[0].setText("");
						
						if (wrong_password_counter >= 10) {
							printer_class.setErrLog("Benutzername oder Passwort wurde zu oft falsch eingegeben, Programm wird beendet...");
									
							System.exit(0);
						}
					}
				}
			}
		});
		
		//autologin für rootmodus
		if (eins_class.rootmode() == true) {
			passwordfields[0].setText("nichtloeschenrootmodus");
			textfields[0].setText("nichtloeschenrootmodus");
			
			buttons[0].doClick();
		}
	}
}
