package controller;

import java.io.IOException;
import ui.Modus;

public class Main {
	public static void main(String[] args) throws IOException {
		System.out.println("Gold Digger - Startvorgang");
		System.out.println(Main.class + " -> abruf");
		
		new Modus(); //wahl zwischen online/offline modus
	}
}
