package ui;

import java.awt.BorderLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.net.URL;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import db.DAOImplementation;
import db.User;
import controller.Clicker;
import controller.Main;
import controller.Offline;
import controller.Printer;

public class Shop extends JPanel implements ActionListener {
	
	JPanel[] panels = new JPanel[100];
	JButton[] buttons = new JButton[100];
	JLabel[] labels = new JLabel[100];
	
	User user_class = new User();
	Printer printer_class = new Printer();
	DAOImplementation dao_class = new DAOImplementation();
	
	public Shop() throws IOException {
		printer_class.setLog(Shop.class + " -> abruf");
		
		
		for (int i = 0; i < 100; i++) {
		    panels[i] = new JPanel();
		    buttons[i] = new JButton();
			labels[i] = new JLabel();
		}
		
		
		setBounds(0, 0, 400, 800);
		setVisible(false);
		setLayout(null);
		
		panels[0].setBounds(22, 70, 340, 220);
		panels[1].setBounds(22, 312, 340, 130);
		panels[2].setBounds(22, 460, 340, 130);
		panels[3].setBounds(22, 608, 340, 130);
		
		
		for (int i = 0; i < 100; i++) {
			buttons[i].setOpaque(false);
			buttons[i].setContentAreaFilled(false);
			buttons[i].setBorderPainted(false);
			
			buttons[i].addActionListener(this);
			
			panels[i].setOpaque(false);
			panels[i].setLayout(new BorderLayout(0, 0));
			
			panels[i].add(buttons[i]);
		}
		
		labels[0].setBounds(0, 0, 385, 761);
						
		URL image_url = Main.class.getResource("/textures/background/shop.png");
						
		BufferedImage image = null;
		try {
			image = ImageIO.read(image_url);
		} catch (IOException e) {
			e.printStackTrace();
		}
						
		Image scaled_image = image.getScaledInstance(labels[0].getWidth(), labels[0].getHeight(), Image.SCALE_REPLICATE); //passt das Bild der Gr��e des JLabels an, "SCALE_REPLICATE" ist die Art wir die Pixel gescaled und Verarbeitet werden
						
		ImageIcon bgimage = new ImageIcon(scaled_image);
						
		labels[0].setIcon(bgimage);
						
		add(labels[0]);
		
		for (int i = 0; i < panels.length; i++) {
			add(panels[i]);
		}
	}
	
	int current_item = 0;
	
	@Override
	public void actionPerformed(ActionEvent e) {
		printer_class.setActionLog("JButton Event > Shop");
		
		int price = 0;
		
		if (Offline.getOfflineMode() == false) {
			if (current_item != 0 && e.getSource() == buttons[0]) {
				JOptionPane.showMessageDialog(this, "Kauf erfolgreich.\nPreis: 0 Gold\nNeuer Kontostand: " + (dao_class.getCurrentPunkte() + price) + " Gold\n\n" + "Stein: +1, Diamand: +2, Smaragd: +1.000, Gold: +100.000");
				Clicker.objekt = 0;
				current_item = 0;
			} else if (current_item != 1 && e.getSource() == buttons[1] && dao_class.getCurrentPunkte() >= 5) {
				price = -5;
				Clicker.objekt = 1;
				current_item = 1;
			} else if (current_item != 2 && e.getSource() == buttons[2] && dao_class.getCurrentPunkte() >= 30) {
				price = -30;
				Clicker.objekt = 2;
				current_item = 2;
			} else if (current_item != 3 && e.getSource() == buttons[3] && dao_class.getCurrentPunkte() >= 10000) {
				price = -10000;
				Clicker.objekt = 3;
				current_item = 3;
			} else {
				printer_class.setLog("Kauf kann nicht fortgesetzt werden");
				JOptionPane.showMessageDialog(this, "Kauf kann nicht fortgesetzt werden. Entweder du hast zu wenig Punkte oder du besitzt diesen Gegenstand bereits.");
			}
		} else {
			if (current_item != 0 && e.getSource() == buttons[0]) {
				JOptionPane.showMessageDialog(this, "Kauf erfolgreich.\nPreis: 0 Gold\nNeuer Kontostand: " + (Offline.getPunkte() + price) + " Gold\n\n" + "Stein: +1, Diamand: +2, Smaragd: +1.000, Gold: +100.000");
				Clicker.objekt = 0;
				current_item = 0;
			} else if (current_item != 1 && e.getSource() == buttons[1] && Offline.getPunkte() >= 5) {
				price = -5;
				Clicker.objekt = 1;
				current_item = 1;
			} else if (current_item != 2 && e.getSource() == buttons[2] && Offline.getPunkte() >= 30) {
				price = -30;
				Clicker.objekt = 2;
				current_item = 2;
			} else if (current_item != 3 && e.getSource() == buttons[3] && Offline.getPunkte() >= 10000) {
				price = -10000;
				Clicker.objekt = 3;
				current_item = 3;
			} else {
				printer_class.setLog("Kauf konnte nicht fortgesetzt werden");
				JOptionPane.showMessageDialog(this, "Kauf kann nicht fortgesetzt werden. Entweder du hast zu wenig Punkte oder du besitzt diesen Gegenstand bereits.");
			}
		}
		
		if (Offline.getOfflineMode() == false) {
			if (price < 0) {
				User currentUser = new User(dao_class.getCurrentUsername(), dao_class.getCurrentPassword(), 0);
				dao_class.getUser(currentUser);
					
				User tokenUser = new User(dao_class.getCurrentUsername(), "", price);
				dao_class.editUser(tokenUser);
						
				JOptionPane.showMessageDialog(this, "Kauf erfolgreich!\n\n" +
												    "Preis: " + Math.abs(price) /*Macht negativ positiv*/ + " Gold\n" +
												    "Neuer Kontostand: " + (dao_class.getCurrentPunkte() + price) +" Gold");
			}
		} else {
			if (price < 0) {
				Offline.setPunkte(price);
						
				JOptionPane.showMessageDialog(this, "Kauf erfolgreich!\n\n" +
					    							"Preis: " + Math.abs(price) /*Macht negativ positiv*/ + " Gold\n" +
					    							"Neuer Kontostand: " + (Offline.getPunkte()) +" Gold");
			}
		}
	}
}
