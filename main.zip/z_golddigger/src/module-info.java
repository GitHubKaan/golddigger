module golddigger {
	requires java.desktop;
	requires java.sql;
	requires ojdbc7;
}