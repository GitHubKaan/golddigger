package controller;

public class Offline {
	
	/*
	 * diese klasse ist ausschließlich für den offlinemodus relevant
	 * hier werden die offline-modus punkte gespeichert und der offline-modus status
	 */
	
	public static boolean offline_modus = false;
	public static int punkte = 0;
	
	
	public static boolean getOfflineMode() { //offlinemodus wird hier abgefragt
		return offline_modus;
	}
	
	public static int getPunkte() { //punkte abfrage
		return punkte;
	}
	public static void setPunkte(int i) { //punkte anpassen
		punkte += i;
	}
}
