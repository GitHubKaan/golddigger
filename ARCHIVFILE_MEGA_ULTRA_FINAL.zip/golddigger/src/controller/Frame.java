package controller;

import java.awt.Point;

public class Frame {
	
	/*
	 * hier wird die "letzte" jframe position abgefragt wenn das fenster an eine andere position verschoben wird
	 * beispiel: anmelde fenster wird verschoben, start fenster öffnet sich an der "letzten" position
	 */
	
	static Point frame_location;
	
	public void setFramePosition(Point l) { //letzte frame position speichern
		System.out.println("jframe position setzten auf: " + l);
		
		frame_location = l;
	}
	public Point getLetzteFramePosition() { //letzte frame position abrufen
		System.out.println("jframe letzte position anfrage, derzeit: " + frame_location);
		
		return frame_location;
	}
}
