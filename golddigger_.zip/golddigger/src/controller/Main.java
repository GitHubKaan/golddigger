package controller;

import java.io.IOException;
import ui.Modus;

public class Main {
	/*
	 * Main Klasse, Software startet hier
	 */
	public static void main(String[] args) throws IOException {
		System.out.println("golddigger startet...");
		
		new Modus(); //erste klasse die startet ist die modusauswahl
	}
}
