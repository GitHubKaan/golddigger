package ui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import controller.Operator;
import controller.Fonts;
import controller.Offline;

public class Modus {
	
	public JFrame frame = new JFrame();
	
	public Modus() throws IOException {
		
		/*
		 * beim programmstart wird angefragt ob man in den offline oder online modus muss
		 */
		
		Fonts font_class = new Fonts();
		
		
		frame.setUndecorated(true);
		frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		frame.setSize(400, 150);
		frame.setLocationRelativeTo(null);
		frame.setResizable(false);
		frame.setAlwaysOnTop(true);
		frame.getContentPane().setBackground(Color.WHITE);
		frame.setLayout(new BorderLayout(0, 0));
		
		JPanel button_panel1 = new JPanel();
		button_panel1.setLayout(null);
		button_panel1.setVisible(true);
		button_panel1.setBounds(200, 110, 90, 35);
		button_panel1.setBackground(Color.BLACK);
		button_panel1.setLayout(new BorderLayout(0, 0));
		
		JPanel button_panel2 = new JPanel();
		button_panel2.setLayout(null);
		button_panel2.setVisible(true);
		button_panel2.setBounds(100, 110, 90, 35);
		button_panel2.setBackground(Color.BLACK);
		button_panel2.setLayout(new BorderLayout(0, 0));
		
		JPanel text_panel = new JPanel();
		text_panel.setVisible(true);
		text_panel.setBackground(Color.WHITE);
		text_panel.setLayout(null);
		
		JButton okbutton = new JButton();
		okbutton.setVisible(true);
		okbutton.setOpaque(false);
		okbutton.setContentAreaFilled(false);
		okbutton.setBorderPainted(false);
		okbutton.setFocusable(false);
		
		JButton okbutton2 = new JButton();
		okbutton2.setVisible(true);
		okbutton2.setOpaque(false);
		okbutton2.setContentAreaFilled(false);
		okbutton2.setBorderPainted(false);
		okbutton2.setFocusable(false);
		
		JLabel buttontext = new JLabel();
		buttontext.setText("<html><b>offline</b></html>");
		buttontext.setForeground(Color.WHITE);
		buttontext.setBounds(0, 0, 100, 100);
		buttontext.setVisible(true);
		buttontext.setFont(font_class.getFont1());
		
		JLabel buttontext2 = new JLabel();
		buttontext2.setText("<html><b>online</b></html>");
		buttontext2.setForeground(Color.WHITE);
		buttontext2.setBounds(0, 0, 100, 100);
		buttontext2.setVisible(true);
		buttontext2.setFont(font_class.getFont1());
		
		JLabel information = new JLabel();
		information.setFont(font_class.getFont1());
		information.setText("<html><b>Wähle einen Modus</b><br/>"
						  + "Online: Mit DB-Anbindung (Konto erforderlich)<br/>"
						  + "Offline: Ohne DB-Anbindung (Konto nicht erforderlich)<br/>"
						  + "Entwickler: F. Adigüzel, K. Turan<br/><br/></html>");
		information.setForeground(Color.BLACK);
		information.setBounds(15, 15, 400, 100);
		information.setVisible(true);
		
		text_panel.add(button_panel1);
		text_panel.add(button_panel2);
		okbutton.add(buttontext);
		okbutton2.add(buttontext2);
		button_panel1.add(okbutton);
		button_panel2.add(okbutton2);
		
		frame.add(text_panel);
		text_panel.add(information);
		
		frame.setVisible(true);
		
		
		okbutton.addActionListener(new ActionListener() { //offline
			@Override
			
			//wenn man den offline-modus auswählt
			public void actionPerformed(ActionEvent e) {
				fehlerwindowaus();
				
				Offline.offline_modus = true;
				
				try {
					new Anmeldung();
				} catch (IOException e1) {
					e1.printStackTrace();
				}
			}
		});
		okbutton2.addActionListener(new ActionListener() { //online
			@Override
			
			//wenn man den online modus auswählt
			public void actionPerformed(ActionEvent e) {
				weiter();
			}
		});
	}
	
	//diese methode wird nur ausgewählt wenn man den online modus betritt (skipstarter oder online auswahl)
	private void weiter() {
		Offline.offline_modus = false;
		fehlerwindowaus();
		
		try {
			new Operator();
			new Anmeldung();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
	}
	
	//modusauswahl wird ausgestellt
	private void fehlerwindowaus() {
		frame.setVisible(false);
		frame.setEnabled(false);
	}
}
