package ui;

import java.awt.BorderLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.net.URL;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import controller.User;
import db.DAOImplementation;
import controller.ClickerEvent;
import controller.Main;
import controller.OfflineMode;
import controller.Printer;

public class Shop extends JPanel implements ActionListener {
	
	JPanel[] panels = new JPanel[100];
	JButton[] buttons = new JButton[100];
	JLabel[] labels = new JLabel[100];
	
	
	User user_class = new User();
	Printer printer_class = new Printer();
	DAOImplementation dao_class = new DAOImplementation();
	
	public Shop() throws IOException {
		printer_class.printLog(Shop.class + " -> abruf");
		
		
		for (int i = 0; i < 100; i++) {
		    panels[i] = new JPanel();
		    buttons[i] = new JButton();
			labels[i] = new JLabel();
		}
		
		
		setBounds(0, 0, 400, 800);
		setVisible(false);
		setLayout(null);
		
		
		//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
		/*
		 * JButtons zum kaufen eines Produktes
		 */
		//aktuelle Angebote
		panels[0].setBounds(22, 70, 340, 220);
		panels[1].setBounds(22, 312, 340, 130);
		panels[2].setBounds(22, 460, 340, 130);
		panels[3].setBounds(22, 608, 340, 130);
		
		
		for (int i = 0; i < 100; i++) {
			buttons[i].setOpaque(false);
			buttons[i].setContentAreaFilled(false);
			buttons[i].setBorderPainted(false);
			
			buttons[i].addActionListener(this);
			
			panels[i].setOpaque(false);
			panels[i].setLayout(new BorderLayout(0, 0));
			
			panels[i].add(buttons[i]);
		}
		
		
		//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
		/*
		 * Hintergrundsebene
		 */		
		labels[0].setBounds(0, 0, 385, 761); //label Gr��e bestimmen
						
		URL image_url = Main.class.getResource("/textures/background/shopbg.png");
						
		BufferedImage image = null;
		try {
			image = ImageIO.read(image_url);
		} catch (IOException e) {
			e.printStackTrace();
		}
						
		Image scaled_image = image.getScaledInstance(labels[0].getWidth(), labels[0].getHeight(), Image.SCALE_REPLICATE); //passt das Bild der Gr��e des JLabels an, "SCALE_REPLICATE" ist die Art wir die Pixel gescaled und Verarbeitet werden
						
		ImageIcon bgimage = new ImageIcon(scaled_image);
						
		labels[0].setIcon(bgimage);
						
		add(labels[0]);
		
		
		
		for (int i = 0; i < panels.length; i++) {
			add(panels[i]);
		}
	}


	
	
	//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
	/*
	 * Actionevents
	 */
	
	int current_item = 0; //0 weil das erste item ein stien ist
	
	@Override
	public void actionPerformed(ActionEvent e) {
		printer_class.actionLog("JButton Event > Shop");
		
		int price = 0;
		
		if (OfflineMode.getOfflineMode() == false) {
			if (current_item != 0 && e.getSource() == buttons[0]) { //Stein
				JOptionPane.showMessageDialog(this, "Kauf erfolgreich.\nPreis: 0 Gold\nNeuer Kontostand: " + (dao_class.getCurrentTokens() + price) + " Gold\n\n" + "Stein: +1, Diamand: +2, Smaragd: +1.000, Gold: +100.000");
				ClickerEvent.Objekt = 0;
				current_item = 0;
			} else if (current_item != 1 && e.getSource() == buttons[1] && dao_class.getCurrentTokens() >= 5) { //Croissant
				price = -5;
				ClickerEvent.Objekt = 1;
				current_item = 1;
			} else if (current_item != 2 && e.getSource() == buttons[2] && dao_class.getCurrentTokens() >= 30) { //Schreibblock
				price = -30;
				ClickerEvent.Objekt = 2;
				current_item = 2;
			} else if (current_item != 3 && e.getSource() == buttons[3] && dao_class.getCurrentTokens() >= 10000) { //Flugzeug
				price = -10000;
				ClickerEvent.Objekt = 3;
				current_item = 3;
			} else { //wenn der Kauf nicht get�tigt werden kann weil man zu wenig Token hat
				printer_class.printLog("Kauf kann nicht fortgesetzt werden");
				JOptionPane.showMessageDialog(this, "Kauf kann nicht fortgesetzt werden. Entweder du hast zu wenig Punkte oder du besitzt diesen Gegenstand bereits.");
			}
		} else {
			if (current_item != 0 && e.getSource() == buttons[0]) { //Stein
				JOptionPane.showMessageDialog(this, "Kauf erfolgreich.\nPreis: 0 Gold\nNeuer Kontostand: " + (OfflineMode.getPunkte() + price) + " Gold\n\n" + "Stein: +1, Diamand: +2, Smaragd: +1.000, Gold: +100.000");
				ClickerEvent.Objekt = 0;
				current_item = 0;
			} else if (current_item != 1 && e.getSource() == buttons[1] && OfflineMode.getPunkte() >= 5) { //Croissant
				price = -5;
				ClickerEvent.Objekt = 1;
				current_item = 1;
			} else if (current_item != 2 && e.getSource() == buttons[2] && OfflineMode.getPunkte() >= 30) { //Schreibblock
				price = -30;
				ClickerEvent.Objekt = 2;
				current_item = 2;
			} else if (current_item != 3 && e.getSource() == buttons[3] && OfflineMode.getPunkte() >= 10000) { //Flugzeug
				price = -10000;
				ClickerEvent.Objekt = 3;
				current_item = 3;
			} else { //wenn der Kauf nicht get�tigt werden kann weil man zu wenig Token hat
				printer_class.printLog("Kauf konnte nicht fortgesetzt werden");
				JOptionPane.showMessageDialog(this, "Kauf kann nicht fortgesetzt werden. Entweder du hast zu wenig Punkte oder du besitzt diesen Gegenstand bereits.");
			}
		}
		
		
		if (OfflineMode.getOfflineMode() == false) {
			if (price < 0) { //wenn etwas gekauft wurde
				User currentUser = new User(dao_class.getCurrentUsername(), dao_class.getCurrentPassword(), 0); //refresh user data
				dao_class.getUser(currentUser);
					
				User tokenUser = new User(dao_class.getCurrentUsername(), "", price);
				dao_class.editUser(tokenUser);
						
				JOptionPane.showMessageDialog(this, "Kauf erfolgreich!\n\n" +
												    "Preis: " + Math.abs(price) /*Macht negativ positiv*/ + " Gold\n" +
												    "Neuer Kontostand: " + (dao_class.getCurrentTokens() + price) +" Gold");
			}
		} else {
			if (price < 0) { //wenn etwas gekauft wurde
				OfflineMode.setPunkte(price);
						
				JOptionPane.showMessageDialog(this, "Kauf erfolgreich!\n\n" +
					    							"Preis: " + Math.abs(price) /*Macht negativ positiv*/ + " Gold\n" +
					    							"Neuer Kontostand: " + (OfflineMode.getPunkte()) +" Gold");
			}
		}
		
	}
}
