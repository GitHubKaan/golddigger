package controller;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.io.IOException;
import java.net.URL;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;

import datenbank.DAOImplementation;
import datenbank.User;

public class Operator implements ActionListener {

	/*
	 * diese klasse ist für den operator relevant (ui und backend)
	 */
	
	static int operatorwindow = 1; //operator-fenster 0=deaktivieren, 1=aktivieren
	
	JPanel[] panels = new JPanel[100];
	JButton[] buttons = new JButton[100];
	JTextField[] textfields = new JTextField[100];
	
	User user_class = new User();
	Fonts fonts_class = new Fonts();
	SYS_Einstellungen eins_class = new SYS_Einstellungen();
	
	
	public Operator() throws IOException {
		
		for (int i = 0; i < 100; i++) {
			panels[i] = new JPanel();
			buttons[i] = new JButton();
			textfields[i] = new JTextField();
		}
		
		for (int i = 0; i < buttons.length; i++) {
			buttons[i].setFocusable(false);
		}
		
		JFrame frame = new JFrame(); //operator jframe
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(400, 160);
		
		if (eins_class.rootmode() == true) { //positionsveränderung bei root-modus
			frame.setLocation(-950, 500);
		} else {
			frame.setLocation(0, 0);
		}
		
		frame.setTitle("Operator Einstellungsmenü");
		frame.setLayout(null);
		frame.setResizable(false);
		frame.getContentPane().setBackground(Color.BLACK);
		
		URL icon_image_url = getClass().getResource("/textures/extra/operator_icon.png");
		ImageIcon icon = new ImageIcon(icon_image_url);
		frame.setIconImage(icon.getImage());
		
		for (int i = 0; i < panels.length; i++) {
			panels[i].setOpaque(false);
			panels[i].setLayout(new BorderLayout(0, 0));
		}
		
		textfields[3].setFont(fonts_class.getFont1());
		
		/*
		 * textfields 0 = benutzernamenfeld zum hinzufügen von punkten
		 * textfields 1 = passwortfeld für kontoerstellung
		 * textfields 3 = benutzernamenfeld für kontoerstellung
		 */
		
		textfields[0].setText("benutzername");
		textfields[1].setText("passwort");
		textfields[3].setText("benutzername");
		
		panels[0].setBounds(0, 0, 300, 30);
		panels[0].add(textfields[3]);
		
		buttons[0].setText("+1");
		panels[1].setBounds(0, 30, 100, 30);
		buttons[1].setText("+10");
		panels[2].setBounds(100, 30, 100, 30);
		buttons[2].setText("+1000");
		panels[3].setBounds(200, 30, 100, 30);
		buttons[6].setText("löschen");
		panels[7].setBounds(300, 0, 85, 30);
		buttons[7].setText("erstellen");
		panels[8].setBounds(300, 90, 85, 30);
		
		
		
		for (int i = 0; i < 8; i++) {
			panels[i + 1].add(buttons[i]);
		}
		
		panels[9].setBounds(0, 90, 150, 30);
		panels[10].setBounds(150, 90, 150, 30);
		
		for (int i = 0; i < 3; i++) {
			panels[i + 9].add(textfields[i]);
		}
		
		for (int i = 0; i < buttons.length; i++) {
			buttons[i].addActionListener(this);
			
			frame.add(panels[i]);
		}
		
		if (operatorwindow == 1 && eins_class.operatorframe() == true) { //wird erst aktiviert wenn online modus ausgewählt wurde bei der modusauswahl und wenn man es in den einstellungen aktiviert
			frame.setVisible(true);
		}
		
		
		
		//action-listener
		textfields[0].addFocusListener((FocusListener) new FocusListener(){ //damit textfields 0 beim klicken gelöscht wird -> benutzerkontoerstellung ("benutzername")
	        @Override
	        public void focusGained(FocusEvent e){
	        	textfields[0].setText("");
	        	
	        	System.out.println("konto erstellen: benutzername feld jetzt frei -> action event");
	        }
			@Override
			public void focusLost(FocusEvent e) {} //event kann nicht entfernt werden
	    });
		textfields[1].addFocusListener((FocusListener) new FocusListener(){ //damit textfields 1 beim klicken gelöscht wird -> benutzerkontoerstellung ("passwort")
	        @Override
	        public void focusGained(FocusEvent e){
	        	textfields[1].setText("");
	        	
	        	System.out.println("konto erstellen: passwort feld jetzt frei -> action event");
	        }
			@Override
			public void focusLost(FocusEvent e) {} //event kann nicht entfernt werden
	    });
	}
	
	
	public void actionPerformed(ActionEvent e) {
		DAOImplementation dao = new DAOImplementation();
		
		//konto löschen option
		if (e.getSource() == buttons[6] && !textfields[3].getText().isEmpty()) { //bedingungen für kontolöschvorgang
			User deleteUser = new User(textfields[3].getText(), "", 0);
		
			dao.deleteUser(deleteUser); //sql anfrage für löschung des benutzers x wird angefragt
				
			textfields[3].setText("");
			
			System.out.println("konto löschen option action event");
		}
		
		//konto erstellen option
		if (e.getSource() == buttons[7]) {
			if (textfields[0].getText().length() > 50 || textfields[1].getText().length() > 50) { //eingabe kontrolle bei erstellung
			} else {
				String benutzername = textfields[0].getText();
				String passwort = textfields[1].getText();
				
				User User = new User(benutzername, passwort, 0);
					
				if (dao.getUser(User) == false && !textfields[0].getText().isEmpty() && !textfields[1].getText().isEmpty()) { //bedingungen für benutzererstellungsvorgang
					dao.addUser(User);
					
					for (int i = 0; i < 3; i++) {
						textfields[i].setText("");
					}
					
					System.out.println("konto erstellen option action event");
				} else {
				}
			}
		}
		
		//punkte geben und nehmen
		for (int i = 0; i < 6; i++) {
			if (e.getSource() == buttons[i] && !textfields[3].getText().isEmpty()) {
				User punkteUser = new User(textfields[3].getText(), "", Integer.parseInt(buttons[i].getText()));
				
				dao.editUser(punkteUser);
				
				System.out.println("punkte geben/nehmen action event");
			}
		}
	}
}
