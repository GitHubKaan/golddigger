package controller;

import datenbank.DAOImplementation;
import datenbank.User;

public class Clicker {
	
	/*
	 * beim klicken auf das objekt wird hier entschieden wie viel punkte man bekommt
	 * online/offline-modus unterscheiden sich bei der punktevergabe
	 * 
	 * muss noch gemacht werden:
	 * 		- fehler bei der vergabe von offline-punkten: es werden +1 zuviele gegeben
	 */
	
	DAOImplementation dao_class = new DAOImplementation();
	
	public static int label_animation = 0; //textgröße wird verändert bei klick-event, hier wird sie zwischengespeichert
	public static int temp_count = 0; //temporärer punktespeicher bei ansichtswechsel zwischen startseite und shop
	public static int objekt = 0; //aktueller gegenstand (aus dem shop) der aktiv ist, hier wird die produkt-id eingetragen
	
	public void clickercclick() {
		
		User punkte = null; //punkte zwischenspeicher
		
		
		if (Offline.getOfflineMode() == false) { //sektion für den online-betrieb (bearbeitung der datenbank)
			if (objekt == 1) { //diamand multiplikator bei klick, +2
				punkte = new User(dao_class.getCurrentUsername(), "", +2);
			} else if (objekt == 2) { //smaragd multiplikator bei klick, +1000
				punkte = new User(dao_class.getCurrentUsername(), "", +1000);
			} else if (objekt == 3) { //gold multiplikator bei klick, +100000
				punkte = new User(dao_class.getCurrentUsername(), "", +100000);
			} else { //stein multiplikator bei klick, +1 (standartmäßig)
				punkte = new User(dao_class.getCurrentUsername(), "", +1);
			}
			
			System.out.println("offline modus punkte anpassung um: " + punkte);
			
			dao_class.editUser(punkte); //bearbeitung der datenbank
			
			
		} else { //sektion für den offline-betrieb (bearbeitung erfolgt zugrunde einer variable in der "Offline"-klasse
			if (objekt == 1) { //diamand multiplikator bei klick, +2
				Offline.setPunkte(2);
			} else if (objekt == 2) { //smaragd multiplikator bei klick, +1000
				Offline.setPunkte(1000);
			} else if (objekt == 3) { //gold multiplikator bei klick, +100000
				Offline.setPunkte(100000);
			} else { //stein multiplikator bei klick, +1 (standartmäßig)
				Offline.setPunkte(1);
			}
			
			System.out.println("online modus punkte anpassung durch objekt: " + objekt);
		}
	};
	
	
	public void setObjekt(int i) { //aktueller shop-gegenstand wird hier modifiziert
		objekt = i;
		
		System.out.println("gegenstand angepasst");
	}
	
	public int getObjekt() { //anfrage zum aktuellen gegenstand der ausgewählt wurde
		System.out.println("gegenstand angefragt");
		
		return objekt;
	}
}
