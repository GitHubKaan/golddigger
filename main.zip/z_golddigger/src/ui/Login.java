package ui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.net.URL;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import controller.User;
import db.DAOImplementation;
import controller.Einstellungen;
import controller.Fonts;
import controller.Frame;
import controller.Main;
import controller.OfflineMode;
import controller.Printer;

public class Login {
	//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
	/*
	 * Objekt Arraylisten und Positionierung
	 * 
	 * Positionsierung:
	 * 		panel 0 - Hintergrundsebene
	 * 		panel 1 - Dropdown Men� (Accountname)
	 * 		panel 2 - Passwort-Textfeld
	 * 		panel 3 - Anmelde-Button
	 */
	JPanel[] panels = new JPanel[100];
	JLabel[] labels = new JLabel[100]; 
	JButton[] buttons = new JButton[100];
	JTextField[] textfields = new JTextField[100];
	JPasswordField[] passwordfields = new JPasswordField[100];
	
	
	static int wrong_password_counter = 0; //bei falscher Passworteingabe steigt der Counter um eins
	
	
	User user_class = new User();
	Printer printer_class = new Printer();
	Frame frame_class = new Frame();
	Fonts fonts_class = new Fonts();
	Einstellungen eins_class = new Einstellungen();
	
	public Login() throws IOException {
		
		printer_class.printLog(Login.class + " -> abruf");
		
		
		for (int i = 0; i < 100; i++) {
		    panels[i] = new JPanel();
			labels[i] = new JLabel();
			buttons[i] = new JButton();
			textfields[i] = new JTextField();
			passwordfields[i] = new JPasswordField();
		}
		
		
		JFrame frame = new JFrame();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(400, 800);
		
		if (frame_class.getLastFrameLocation() == null) {
			if (eins_class.rootmode() == true) {
				frame.setLocation(-450, 500);
			} else {
				frame.setLocationRelativeTo(null);
			}
		} else {
			frame.setLocation(frame_class.getLastFrameLocation());
		}
		
		frame.setTitle("hwrpb_system - login ui");
		frame.setLayout(null);
		frame.setResizable(false);
		
		URL icon_image_url = getClass().getResource("/textures/extra/icon.png");
		ImageIcon icon = new ImageIcon(icon_image_url);
		frame.setIconImage(icon.getImage());
		
		
		for (int i = 0; i < panels.length; i++) {
		    panels[i].setOpaque(false);
		    panels[i].setLayout(new BorderLayout(0, 0)); //Funktioniert wie ".pack" damit die Objekte sich an die Gr��e des "panels" anpassen
		}
		
		
		//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
		/*
		* JTextField f�r Accountname
		*/
		textfields[0].setFont(fonts_class.getFontTypeA());
		
		panels[1].setBounds(35, 390, 315, 45);
		panels[1].add(textfields[0]);
		
		frame.add(panels[1]);
		
		
		//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
		/*
		* Passwort-Textfeld
		*/
		passwordfields[0].setFont(fonts_class.getFontTypeA());
		
		panels[2].setBounds(35, 441, 315, 45);
		panels[2].add(passwordfields[0]);
		
		frame.add(panels[2]);
		
		
		//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
		/*
		* Anmelde-Button
		*/
		buttons[0].setOpaque(false); //button Schatten, Texture etc. unsichtbar machen
		buttons[0].setContentAreaFilled(false);
		buttons[0].setBorderPainted(false);
		
		panels[3].setBounds(120, 500, 145, 45);
		panels[3].add(buttons[0]);
		
		frame.add(panels[3]);
		
		
		//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
		/*
		 * Hintergrundsebene
		 */
		labels[0].setBounds(0, 0, 385, 761); //label Gr��e bestimmen
		
		URL image_url = Main.class.getResource("/textures/background/loginbg.png");
		
		BufferedImage image = null;
		try { //Bild Import
			image = ImageIO.read(image_url);
		} catch (IOException e) {
		    e.printStackTrace();
		}
		
		Image scaled_image = image.getScaledInstance(labels[0].getWidth(), labels[0].getHeight(), Image.SCALE_REPLICATE); //passt das Bild der Gr��e des JLabels an, "SCALE_REPLICATE" ist die Art wir die Pixel gescaled und verarbeitet werden
		
		ImageIcon bgimage = new ImageIcon(scaled_image);
		
		labels[0].setIcon(bgimage);
		
		frame.add(labels[0]);
		
		
		frame.setVisible(true);
		
		//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
		/*
		 * Actionevents
		 */
		textfields[0].addActionListener(new ActionListener() { //damit man wenn man auf Enter dr�ckt bei dem Benutzernamen zum Passwort JTextField kommt
			@Override
			public void actionPerformed(ActionEvent e) {
				passwordfields[0].requestFocus(); //setzt den Fokus auf das zweite Textfeld
			}
		});
		
		passwordfields[0].addActionListener(new ActionListener() { //wenn man im "password_field" auf die Entertaste dr�ckt soll man den JButton ausl�sen
			@Override
			public void actionPerformed(ActionEvent e) {
				buttons[0].doClick(); //l�st einen Klick aus
			}
		});
		
		buttons[0].addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) { //Actionevent
				
				if (OfflineMode.getOfflineMode() == true) { //für offline modus
					
					System.out.println("------------------------------------------------");
					frame_class.setFrameLocation(frame.getLocation()); //speichert die Position des Login-JFrames ab
					frame.setVisible(false); //schaltet den Frame aus
					wrong_password_counter = 0; //falsche Passwort Eingaben werden wiederhergestellt f�r den n�chsten Login Versuch
					try {
						new Home(); //home klasse wird importiert
					} catch (IOException e2) {
						printer_class.errLog("\"Home\" Klasse konnte nicht gestartet werden");
					}
				} else {
					printer_class.actionLog("JButton Action > Login");
					
					
					// []--------------------<<|[ABSCHNITT]|>>--------------------[]
					/*
					 * Anmelden
					 */
					DAOImplementation dao = new DAOImplementation();
					
					
					User currentUser = new User(textfields[0].getText(), passwordfields[0].getText(), 0);
					
					if (dao.getUser(currentUser) == true) {
						printer_class.printLog("Login hat funktioniert");
						
						//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
						/*
						 * richtiges Passwort wurde eingegeben
						 */
						printer_class.printLog("Passwort korrekt, Login erfolgt...");
						
						frame_class.setFrameLocation(frame.getLocation()); //speichert die Position des Login-JFrames ab
						
						frame.setVisible(false); //schaltet den Frame aus
						
						wrong_password_counter = 0; //falsche Passwort Eingaben werden wiederhergestellt f�r den n�chsten Login Versuch
						
						try {
							new Home(); //home klasse wird importiert
						} catch (IOException e2) {
							printer_class.errLog("\"Home\" Klasse konnte nicht gestartet werden");
						}
						
					} else {
						printer_class.errLog("Login hat nicht funktioniert");
						
						
						
						//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
						/*
						 * falsches Passwort wurde eingegeben
						 */
						printer_class.errLog("Passwort inkorrekt");
						
						Color loginWrong = new Color(255, 177, 177);
						textfields[0].setBackground(loginWrong); //Textfeld rot anmalen
						passwordfields[0].setBackground(loginWrong);
						
						wrong_password_counter++; //Bei falscher Eingabe steigt der Counter bis maximal drei
						
						textfields[0].requestFocus(); //setzt den Fokus wieder auf das Feld des Benutzernamens
						
						printer_class.printLog("falsches Passwort (Versuch): " + wrong_password_counter + "/10");
						
						
						//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
						/*
						 * was in beiden F�llen passiert
						 */
						passwordfields[0].setText(""); //Passwort-Textfeld l�schen
						textfields[0].setText(""); //Benutzername-Textfeld l�schen
						
						if (wrong_password_counter >= 10) { //Beendet das Programm wenn das Passwort drei mal falsch eingegeben wurde
							printer_class.errLog("Benutzername oder Passwort wurde zu oft falsch eingegeben, Programm wird beendet...");
									
							System.exit(0); //software wird gestoppt
						}
					}
				}
			}
		});
		
		if (eins_class.rootmode() == true) { //autologin für rootmodus
			passwordfields[0].setText("nichtloeschenrootmodus");
			textfields[0].setText("nichtloeschenrootmodus");
			
			buttons[0].doClick();
		}
	}
}
