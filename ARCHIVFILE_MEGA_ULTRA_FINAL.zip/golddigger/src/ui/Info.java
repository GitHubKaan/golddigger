package ui;

import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.net.URL;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import controller.Main;

public class Info extends JPanel {
	
	JPanel[] panels = new JPanel[100];
	JLabel[] labels = new JLabel[100];
	
	public Info() throws IOException {
		
		/*
		 * info seite
		 */
		
		for (int i = 0; i < 100; i++) {
		    panels[i] = new JPanel();
			labels[i] = new JLabel();
		}
		
		setBounds(0, 0, 400, 800);
		setVisible(false);
		setLayout(null);
		
		for (int i = 0; i < panels.length; i++) {
		    panels[i].setOpaque(false);
		}
		
		panels[0].setBounds(0, 0, 385, 761); //enspricht 400 und 800 JFrame Pixeln warum auch immer
		panels[0].setLayout(null);
				
		labels[0].setBounds(0, 0, 385, 761);
				
		URL image_url = Main.class.getResource("/textures/background/info.png");
				
		BufferedImage image = null;
		try {
			image = ImageIO.read(image_url);
		} catch (IOException e) {
			e.printStackTrace();
		}
				
		Image scaled_image = image.getScaledInstance(labels[0].getWidth(), labels[0].getHeight(), Image.SCALE_REPLICATE);
				
		ImageIcon bgimage = new ImageIcon(scaled_image);
				
		labels[0].setIcon(bgimage);
				
		panels[0].add(labels[0]);
		
		
		for (int i = 0; i < panels.length; i++) {
			add(panels[i]);
		}
	}
}
