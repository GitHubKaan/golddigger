package controller;

import db.DAOImplementation;
import db.User;

public class Clicker {
	
	DAOImplementation dao_class = new DAOImplementation();
	
	public static int label_animation = 0; //textgrößenveränderung bei klick
	public static int ani_count = 0; //temporärer punkte speicher für ansichtenwechsel zwischen home und shop
	public static int objekt = 0; //gegenstand aus dem shop (produkt-id)
	
	public void clickercclick() {
		
		User tokenUser = null;
		
		if (Offline.getOfflineMode() == false) { //für den online betrieb
			if (objekt == 1) { //diamand multiplikator bei klick
				tokenUser = new User(dao_class.getCurrentUsername(), "", +2);
			} else if (objekt == 2) { //smaragd multiplikator bei klick
				tokenUser = new User(dao_class.getCurrentUsername(), "", +1000);
			} else if (objekt == 3) { //gold multiplikator bei klick
				tokenUser = new User(dao_class.getCurrentUsername(), "", +100000);
			} else { //stone multiplikator bei klick
				tokenUser = new User(dao_class.getCurrentUsername(), "", +1);
			}
			dao_class.editUser(tokenUser);
		} else { //für den offline betrieb
			if (objekt == 1) { //diamand multiplikator bei klick
				Offline.setPunkte(2);
			} else if (objekt == 2) { //smaragd multiplikator bei klick
				Offline.setPunkte(1000);
			} else if (objekt == 3) { //gold multiplikator bei klick
				Offline.setPunkte(100000);
			} else { //stone multiplikator bei klick
				Offline.setPunkte(1);
			}
		}
	};
	
	public void setObjekt(int i) { //aktuellen gegenstand aus dem shop anpassen
		objekt = i;
	}
	
	public int getObjekt() { //aktuellen gegenstand aus dem shop anfordern
		return objekt;
	}
}
