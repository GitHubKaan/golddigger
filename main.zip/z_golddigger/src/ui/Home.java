package ui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.net.URL;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.Timer;

import controller.User;
import db.DAOImplementation;
import controller.ClickerEvent;
import controller.Fonts;
import controller.Frame;
import controller.Main;
import controller.Printer;

public class Home implements ActionListener {
	
	//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
	/*
	 * Positionierung
	 * 
	 * Positionsierung:
	 * 		panel 1 - Einstellungen
	 * 		panel 2 - Nachricht
	 * 		panel 3 - Shop
	 * 		panel 4 - Anleitung
	 *		panel 5 - Zur�ck
	 *		panel 6 - Token Anzeige
	 */
	JPanel[] panels = new JPanel[100];
	JLabel[] labels = new JLabel[100]; 
	JButton[] buttons = new JButton[100];
	
	
	User user_class = new User();
	Settings settings_class = new Settings();
	Help help_class = new Help();
	Shop shop_class = new Shop();
	Printer printer_class = new Printer();
	Frame frame_class = new Frame();
	Fonts fonts_class = new Fonts();
	DAOImplementation dao_class = new DAOImplementation();
	ClickerEvent ce_class = new ClickerEvent();
	
	JFrame frame = new JFrame();
	JButton clicker = new JButton();
	Timer timer;
	
	public Home() throws IOException {
		printer_class.printLog(Home.class + " -> abruf");
		
		for (int i = 0; i < 100; i++) {
		    panels[i] = new JPanel();
			labels[i] = new JLabel();
			buttons[i] = new JButton();
		}
		
		
		
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(400, 800);
		frame.setTitle("hwrpb_system - home ui");
		frame.setResizable(true);
		frame.setLocation(frame_class.getLastFrameLocation()); //Platziert den Home-JFrame dort hin wo der Login-JFrame zuletzt war
		
		URL icon_image_url = getClass().getResource("/textures/extra/icon.png");
		ImageIcon icon = new ImageIcon(icon_image_url);
		frame.setIconImage(icon.getImage());
		
		
		frame.add(settings_class); //extends JPanel
		frame.add(help_class);
		frame.add(shop_class);
		
		
		for (int i = 0; i < panels.length; i++) { //JPanels unsichtbar machen
		    panels[i].setOpaque(false);
		    panels[i].setLayout(new BorderLayout(0, 0)); //Funktioniert wie ".pack" damit die Objekte sich an die Gr��e des "panels" anpassen
		}
		
		
		panels[1].setBounds(349, 5, 30, 30);
		panels[2].setBounds(30, 134, 385, 79); //nachricht
		panels[3].setBounds(10, 672, 80, 80);
		panels[4].setBounds(316, 5, 30, 30);
		panels[5].setBounds(10, 10, 35, 35);
		
		for (int i = 1; i < 6; i++) {
			if (i != 2) {
				panels[i].add(buttons[i - 1]); //-1 weil die Schleife bei eins startet
			}
		}
		// 1 - panel 1 add button 0: Einstellungen
		// 2 - x
		// 3 - panel 3 add button 2: Shop
		// 4 - panel 4 add button 3: Hilfe
		// 5 - panel 5 add button 4: Zur�ck Button
		
		
		for (int i = 0; i < buttons.length; i++) {
			buttons[i].setOpaque(false);
			buttons[i].setContentAreaFilled(false);
			buttons[i].setBorderPainted(false);
			
			buttons[i].addActionListener(this);
		}
		
		
		//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
		/*
		 * Token Anzeige
		 */
		labels[1].setFont(fonts_class.getFontTypeD());
		
		validateToken(); //Kontostand Abfragen/erneuern
		
		panels[6].setBounds(40, 8, 288, 30);
		panels[6].add(labels[1]);
		
		
		
		
		
		
		for (int i = 0; i < panels.length; i++) {
			frame.add(panels[i]);
		}
		
		
		
		labels[0].setBounds(0, 0, 385, 761); //label Gr��e bestimmen
		
		URL image_url = Main.class.getResource("/textures/background/homebg_basic.png");
		
		BufferedImage image = null;
		try { //Bild Import
			image = ImageIO.read(image_url);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		Image scaled_image = image.getScaledInstance(labels[0].getWidth(), labels[0].getHeight(), Image.SCALE_REPLICATE); //passt das Bild der Gr��e des JLabels an, "SCALE_REPLICATE" ist die Art wir die Pixel gescaled und verarbeitet werden
		
		ImageIcon bgimage = new ImageIcon(scaled_image);
		
		labels[0].setIcon(bgimage);
		labels[0].setBounds(0, 0, 385, 761);
				
		
		
		
		//---------------------------------------------------------------------------------------------------------
		//----------------------------------[     CLICKER - START      ]-------------------------------------------
		//---------------------------------------------------------------------------------------------------------
		
		int clicker_size = 250;
		
		
		JPanel clicker_panel = new JPanel();
		  
		clicker.setLocation(0, 0);
		clicker.setVisible(true);
		clicker.setBackground(Color.RED);
		clicker.setOpaque(true);
		clicker.setBorderPainted(false);
		clicker.setFocusable(false);
		clicker.setRolloverEnabled(false);
		clicker.setLayout(new BorderLayout(0, 0));
		
		try {
			Image img = null;
			
			if (ce_class.getObjekt() == 0) {
				 img = ImageIO.read(getClass().getResource("/textures/background/stone.png"));
			} else if (ce_class.getObjekt() == 1) {
				img = ImageIO.read(getClass().getResource("/textures/background/diamond.png"));
			} else if (ce_class.getObjekt() == 2) {
				img = ImageIO.read(getClass().getResource("/textures/background/smaragd.png"));
			} else if (ce_class.getObjekt() == 3) {
				img = ImageIO.read(getClass().getResource("/textures/background/gold.png"));
			}
			
			clicker.setIcon(new ImageIcon(img));
			
		} catch (Exception ex) {}
		
		clicker_panel.setLayout(null);
		clicker_panel.setLayout(new BorderLayout(0, 0));
		clicker_panel.setBounds(68, 260, clicker_size, clicker_size);
		
		clicker_panel.add(clicker);
		frame.add(clicker_panel);
		
		clicker.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				clicker.setBackground(new Color(0f, 0f, 0f, 0f));
				
				ce_class.clickercclick();
				
				
				
				
				
				printer_class.printLog("clicker wurde betätigt");
				
				if (ClickerEvent.Objekt == 0) {
					ClickerEvent.ani_count += 1;
				} else if (ClickerEvent.Objekt == 1) {
					ClickerEvent.ani_count += 2;
				} else if (ClickerEvent.Objekt == 2) {
					ClickerEvent.ani_count += 1000;
				} else if (ClickerEvent.Objekt == 3) {
					ClickerEvent.ani_count += 100000;
				}
				
				
				labels[1].setFont(new Font("Calibri", Font.BOLD, 18));
				labels[1].setText(Integer.toString(dao_class.getCurrentTokens() + ClickerEvent.ani_count) + " Gold");
				
				clicker.setEnabled(false);
				clicker.setVisible(false);
				
				//ANIMATION
				boolean test = false;
				timer = new Timer(10, new ActionListener() { 
					@Override
					public void actionPerformed(ActionEvent e) {
						
						if (ClickerEvent.label_animation > 10) {
							printer_class.printLog("abbruch animation");
							timer.stop();
							
							clicker.setEnabled(true);
							clicker.setVisible(true);
						}
						
						ClickerEvent.label_animation+=1;
						
						//System.out.println(ClickerEvent.label_animation);
						
						animation();
					}
				});
				if (!timer.isRunning()) {
					timer.start(); //startet timer
				}
				
				
				ClickerEvent.label_animation=0;
				//-------------------------------------------------------
			}
		});
		
		//---------------------------------------------------------------------------------------------------------
		//----------------------------------[     CLICKER - ENDE      ]--------------------------------------------
		//---------------------------------------------------------------------------------------------------------
		
		
		
		
		
		
		frame.add(labels[0]);
		
		frame.setVisible(true);
		
		
		//ActionEvent der Settings Klasse ist in Home weil es sich sonst looped
		//Klassen w�rde sich gegenseitig Abrufen, unendlich oft
		//Daher alle ActionEVents von der Oberstehenden Klasse
		settings_class.buttons[1].addActionListener(new ActionListener() { //abmelden
			@Override
			public void actionPerformed(ActionEvent e) {
				
				frame.setVisible(false);
				
				frame_class.setFrameLocation(frame.getLocation());
				
				try {
					new Login(); //start Login Klasse
				} catch (IOException e1) {
					e1.printStackTrace();
				}
				
				printer_class.actionLog("JButton Event > Settings");
				
				printer_class.printLog("Benutzer wird abgemeldet...");
			}
		});
	}
	
	
	public void actionPerformed(ActionEvent e) {
		printer_class.actionLog("JButton Event > Home");
		
		if (e.getSource() == buttons[0]) { //Einstellungen
			settings_class.setVisible(true);
			homeClose();
		}
		
		if (e.getSource() == buttons[2]) { //Shop
			ClickerEvent.ani_count = 0;
			validateToken();
			shop_class.setVisible(true);
			homeClose();
		}
		
		if (e.getSource() == buttons[3]) { //Hilfe
			help_class.setVisible(true);;
			homeClose();
		}
		
		//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
		/*
		 * Actionevents die von anderen Klassen ausgef�hrt werden k�nnen
		 */
		if (e.getSource() == buttons[4]) { //Zur�ck JButton schaltet wieder auf die Home-Klasse zur�ck
			settings_class.setVisible(false);
			help_class.setVisible(false);
			shop_class.setVisible(false);
			
			settings_class.previousPage();
			
			validateToken();
			
			homeOpen();
		}
	}
	
	
	//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
	/*
	 * Aktivierungs und Deaktivierungs Optionen bei Verlassen der Home-Klasse
	 */
	private void homeOpen() {
		for (int i = 0; i < buttons.length; i++) {
			buttons[i].setVisible(true); //aktiviert
		}
	}
	
	private void homeClose() {
		for (int i = 0; i < buttons.length; i++) {
			if (i != 4) { //weil der vierte Button zum Zur�ckgehen gedacht ist
				buttons[i].setVisible(false); //deaktiviert (nicht klickbar)
			}
		}
	}
	
	
	//[]--------------------<<|[ABSCHNITT]|>>--------------------[]
	/*
	 * Ausgabeeinstellungen der Token Anzeige
	 */
	private void validateToken() {
		
		User currentUser = new User(dao_class.getCurrentUsername(), dao_class.getCurrentPassword(), 0); //aktuallisierung der aktuellen Benutzerdaten
		dao_class.getUser(currentUser);
		
		Integer currentTokens = dao_class.getCurrentTokens();
		
		
		
		if (currentTokens >= 0 && currentTokens < 10000000) { //von 0 bis 10000000
			labels[1].setForeground(Color.BLACK);
			labels[1].setText(currentTokens.toString() + " Gold");
		} else {
			labels[1].setText("FEHLER");
			
			if (currentTokens < 0) {
				User tokenUser = new User(dao_class.getCurrentUsername(), "", -1*currentTokens); //wenn zahl kleiner als 0 ist
				dao_class.editUser(tokenUser);
			} else {
				User tokenUser = new User(dao_class.getCurrentUsername(), "", -currentTokens); //wenn sie größer als 9999999 ist
				dao_class.editUser(tokenUser);
			}
			
		}
		
		
		labels[1].setFont(new Font("Calibri", Font.BOLD, 19));
		
		try {
			Image img = null;
			
			if (ce_class.getObjekt() == 0) {
				 img = ImageIO.read(getClass().getResource("/textures/background/stone.png"));
			} else if (ce_class.getObjekt() == 1) {
				img = ImageIO.read(getClass().getResource("/textures/background/diamond.png"));
			} else if (ce_class.getObjekt() == 2) {
				img = ImageIO.read(getClass().getResource("/textures/background/smaragd.png"));
			} else if (ce_class.getObjekt() == 3) {
				img = ImageIO.read(getClass().getResource("/textures/background/gold.png"));
			}
			
			clicker.setIcon(new ImageIcon(img));
			
		} catch (Exception ex) {}
	}
	
	private void animation() { //geht nicht
		labels[1].setFont(new Font("Calibri", Font.BOLD, 5 + ClickerEvent.label_animation));
		frame.repaint();
	}
}
