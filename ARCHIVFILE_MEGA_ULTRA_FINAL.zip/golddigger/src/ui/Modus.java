package ui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import controller.Operator;
import controller.SYS_Einstellungen;
import controller.Fonts;
import controller.Offline;

public class Modus {
	
	public JFrame frame = new JFrame();
	public SYS_Einstellungen einst = new SYS_Einstellungen();
	
	public Modus() throws IOException {
		
		/*
		 * beim programmstart wird angefragt ob man in den offline oder online modus muss
		 */
		
		Fonts font_class = null;
		font_class = new Fonts();
		
		
		frame.setUndecorated(true);
		frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		frame.setSize(400, 150);
		frame.setLocationRelativeTo(null);
		frame.setResizable(false);
		frame.setAlwaysOnTop(true);
		frame.getContentPane().setBackground(Color.WHITE);
		frame.setLayout(new BorderLayout(0, 0));
		
		JPanel bbackground = new JPanel();
		bbackground.setLayout(null);
		bbackground.setVisible(true);
		bbackground.setBounds(200, 110, 90, 35);
		bbackground.setBackground(Color.BLACK);
		bbackground.setLayout(new BorderLayout(0, 0));
		
		JPanel bbackground3 = new JPanel();
		bbackground3.setLayout(null);
		bbackground3.setVisible(true);
		bbackground3.setBounds(100, 110, 90, 35);
		bbackground3.setBackground(Color.BLACK);
		bbackground3.setLayout(new BorderLayout(0, 0));
		
		JPanel bbackground2 = new JPanel();
		bbackground2.setVisible(true);
		bbackground2.setBackground(Color.WHITE);
		bbackground2.setLayout(null);
		
		JButton okbutton = new JButton();
		okbutton.setVisible(true);
		okbutton.setOpaque(false);
		okbutton.setContentAreaFilled(false);
		okbutton.setBorderPainted(false);
		okbutton.setFocusable(false);
		
		JButton okbutton2 = new JButton();
		okbutton2.setVisible(true);
		okbutton2.setOpaque(false);
		okbutton2.setContentAreaFilled(false);
		okbutton2.setBorderPainted(false);
		okbutton2.setFocusable(false);
		
		JLabel buttontext = new JLabel();
		buttontext.setText("<html><b>offline</b></html>");
		buttontext.setForeground(Color.WHITE);
		buttontext.setBounds(0, 0, 100, 100);
		buttontext.setVisible(true);
		buttontext.setFont(font_class.getFont1());
		
		JLabel buttontext2 = new JLabel();
		buttontext2.setText("<html><b>online</b></html>");
		buttontext2.setForeground(Color.WHITE);
		buttontext2.setBounds(0, 0, 100, 100);
		buttontext2.setVisible(true);
		buttontext2.setFont(font_class.getFont1());
		
		JLabel information = new JLabel();
		information.setFont(font_class.getFont1());
		information.setText("<html><b>Wähle einen Modus</b><br/>"
						  + "Online: Mit DB-Anbindung (Konto erforderlich)<br/>"
						  + "Offline: Ohne DB-Anbindung (Konto nicht erforderlich)<br/>"
						  + "Entwickler: F. Adigüzel, K. Turan<br/><br/></html>");
		information.setForeground(Color.BLACK);
		information.setBounds(15, 15, 400, 100);
		information.setVisible(true);
		
		bbackground2.add(bbackground);
		bbackground2.add(bbackground3);
		okbutton.add(buttontext);
		okbutton2.add(buttontext2);
		bbackground.add(okbutton);
		bbackground3.add(okbutton2);
		
		frame.add(bbackground2);
		bbackground2.add(information);
		
		if (einst.skipstarter() == true) { //wenn der startet gescippt wird
			weiter();
		} else {
			frame.setVisible(true);
		}
		okbutton.addActionListener(new ActionListener() { //offline
			@Override
			
			//wenn man den offline-modus auswählt
			public void actionPerformed(ActionEvent e) {
				fehlerwindowaus();
				
				Offline.offline_modus = true;
				
				try {
					new Anmeldung();
				} catch (IOException e1) {
					e1.printStackTrace();
				}
			}
		});
		okbutton2.addActionListener(new ActionListener() {
			@Override
			
			//wenn man den online modus auswählt
			public void actionPerformed(ActionEvent e) {
				weiter();
			}
		});
	}
	
	//diese methode wird nur ausgewählt wenn man den online modus betritt (skipstarter oder online auswahl)
	private void weiter() {
		Offline.offline_modus = false;
		fehlerwindowaus();
		
		try {
			new Operator();
			new Anmeldung();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
	}
	
	//modusauswahl wird ausgestellt
	private void fehlerwindowaus() {
		frame.setVisible(false);
		frame.setEnabled(false);
	}
}
