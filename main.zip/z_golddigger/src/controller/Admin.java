package controller;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.io.IOException;
import java.net.URL;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;

import db.DAOImplementation;

public class Admin implements ActionListener {

	static int adminwindow = 1; // 0 = inaktiv, 1 = aktiv
	
	
	// []--------------------<<|[ABSCHNITT]|>>--------------------[]
	/*
	 * Positionierung
	 * 
	 * Positionsierung:
	 * panel 0 - Dropdown Men� (Accountname)
	 * panel 1 - +1 Token
	 * panel 2 - +5 Token
	 * panel 3 - +10 Token
	 * panel 4 - -1 Token
	 * panel 5 - -5 Token
	 * panel 6 - -10 Token
	 * panel 7 - Benutzer l�schen
	 * panel 8 - Benutzer hinzuf�gen
	 * panel 9 - Benutzername hinzuf�gen
	 * panel 10 - Passwort hinzuf�gen
	 * panel 11 - Token hinzuf�gen
	 */
	
	JPanel[] panels = new JPanel[100];
	JButton[] buttons = new JButton[100];
	JTextField[] textfields = new JTextField[100];
	User user_class = new User();
	Printer printer_class = new Printer();
	Fonts fonts_class = new Fonts();
	Einstellungen eins_class = new Einstellungen();
	
	public Admin() throws IOException {
		printer_class.printLog(Admin.class + " -> abruf");

		
		for (int i = 0; i < 100; i++) {
			panels[i] = new JPanel();
			buttons[i] = new JButton();
			textfields[i] = new JTextField();
		}
		
		
		JFrame frame = new JFrame();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(400, 160);
		if (eins_class.rootmode() == true) {
			frame.setLocation(-950, 500);
		} else {
			frame.setLocation(0, 0);
		}
		
		frame.setTitle("admin");
		frame.setLayout(null);
		frame.setResizable(false);
		frame.getContentPane().setBackground(Color.BLACK);

		
		URL icon_image_url = getClass().getResource("/textures/extra/icon2.png");
		ImageIcon icon = new ImageIcon(icon_image_url);
		frame.setIconImage(icon.getImage());

		
		for (int i = 0; i < panels.length; i++) {
			panels[i].setOpaque(false);
			panels[i].setLayout(new BorderLayout(0, 0));
		}
		
		
		textfields[3].setFont(fonts_class.getFontTypeA());
		
		textfields[3].setText("benutzername");
		textfields[0].setText("benutzername");
		textfields[1].setText("passwort");
		
		panels[0].setBounds(0, 0, 300, 30);
		panels[0].add(textfields[3]);
		
		
		buttons[0].setText("+1");
		panels[1].setBounds(0, 30, 100, 30);
		buttons[1].setText("+10");
		panels[2].setBounds(100, 30, 100, 30);
		buttons[2].setText("+1000");
		panels[3].setBounds(200, 30, 100, 30);
		buttons[6].setText("löschen");
		panels[7].setBounds(300, 0, 85, 30);
		buttons[7].setText("erstellen");
		panels[8].setBounds(300, 90, 85, 30);

		for (int i = 0; i < 8; i++) {
			panels[i + 1].add(buttons[i]);
		}
		
		
		panels[9].setBounds(0, 90, 150, 30);
		panels[10].setBounds(150, 90, 150, 30);
		
		for (int i = 0; i < 3; i++) {
			panels[i + 9].add(textfields[i]);
		}
		
		
		for (int i = 0; i < buttons.length; i++) {
			buttons[i].addActionListener(this);
			
			frame.add(panels[i]);
		}
		
		
		if (adminwindow == 1 && eins_class.adminpanel() == true) {
			frame.setVisible(true);
		}
		
		textfields[0].addFocusListener((FocusListener) new FocusListener(){
	        @Override
	        public void focusGained(FocusEvent e){
	        	textfields[0].setText("");
	        }
			@Override
			public void focusLost(FocusEvent e) {
				// TODO Auto-generated method stub
				
			}
	    });
		textfields[1].addFocusListener((FocusListener) new FocusListener(){
	        @Override
	        public void focusGained(FocusEvent e){
	        	textfields[1].setText("");
	        }
			@Override
			public void focusLost(FocusEvent e) {
				// TODO Auto-generated method stub
				
			}
	    });
	}
	
	
	public void actionPerformed(ActionEvent e) {
		printer_class.actionLog("JButton Action > Admin");
		
		
		DAOImplementation dao = new DAOImplementation();
		
		
		//Konto L�schen
		if (e.getSource() == buttons[6] && !textfields[3].getText().isEmpty()) {
			User deleteUser = new User(textfields[3].getText(), "", 0);
		
			dao.deleteUser(deleteUser);
				
			textfields[3].setText("");
		}
		
		
		
		//Konto-Erstellen Action
		if (e.getSource() == buttons[7]) {
			if (textfields[0].getText().length() > 50 || textfields[1].getText().length() > 50) { //wenn Eingaben zu gro� sind
				printer_class.errLog("Eingabe zu gro�, bitte w�hle kleinere Eingabewerte (Passwort/Benutzername: max 50, Token: max 7)");
			} else {
				String benutzername = textfields[0].getText();
				String passwort = textfields[1].getText();
				
			
					
				User User = new User(benutzername, passwort, 0);
					
				if (dao.getUser(User) == false && !textfields[0].getText().isEmpty() && !textfields[1].getText().isEmpty()) { //Kontrolle erfolgt hier
					dao.addUser(User);
						
					for (int i = 0; i < 3; i++) {
						textfields[i].setText("");
					}
				} else {
					printer_class.errLog("Fehlerhafte Eingabe");
				}
			}
		}
		
		
		
		
		//Tokens geben/nehmen
		for (int i = 0; i < 6; i++) {
			if (e.getSource() == buttons[i] && !textfields[3].getText().isEmpty()) {
				User tokenUser = new User(textfields[3].getText(), "", Integer.parseInt(buttons[i].getText()));
				dao.editUser(tokenUser);
			}
		}
	}
}
