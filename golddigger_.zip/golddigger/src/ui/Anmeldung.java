package ui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.net.URL;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import controller.Fonts;
import controller.Frame;
import controller.Main;
import controller.Offline;
import datenbank.DAOImplementation;
import datenbank.User;

public class Anmeldung {
	
	//ui array initialisierung
	JPanel[] panels = new JPanel[100];
	JLabel[] labels = new JLabel[100]; 
	JButton[] buttons = new JButton[100];
	JTextField[] textfields = new JTextField[100];
	JPasswordField[] passwordfields = new JPasswordField[100];
	
	//klassen import
	User user_class = new User();
	Frame frame_class = new Frame();
	Fonts fonts_class = new Fonts();
	DAOImplementation dao = new DAOImplementation();
	
	public Anmeldung() throws IOException {
		
		/*
		 * anmelde fenster
		 */
		
		for (int i = 0; i < 100; i++) {
		    panels[i] = new JPanel();
			labels[i] = new JLabel();
			buttons[i] = new JButton();
			textfields[i] = new JTextField();
			passwordfields[i] = new JPasswordField();
		}
		
		JFrame frame = new JFrame();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(400, 800);
		
		if (frame_class.getLetzteFramePosition() == null) { //abfrage letzter jframe position wenn vorhanden
			frame.setLocationRelativeTo(null);
		} else { //vorhanden
			frame.setLocation(frame_class.getLetzteFramePosition());
		}
		
		frame.setTitle("Gold Digger - Anmeldung");
		frame.setLayout(null);
		frame.setResizable(false);
		
		URL icon_image_url = getClass().getResource("/textures/extra/icon.png");
		ImageIcon icon = new ImageIcon(icon_image_url);
		frame.setIconImage(icon.getImage());
		
		
		for (int i = 0; i < panels.length; i++) {
		    panels[i].setOpaque(false);
		    panels[i].setLayout(new BorderLayout(0, 0));
		}
		
		//accountname
		textfields[0].setFont(fonts_class.getFont1());
		
		panels[1].setBounds(35, 390, 315, 45);
		panels[1].add(textfields[0]);
		
		frame.add(panels[1]);
		
		//passwortfeld
		passwordfields[0].setFont(fonts_class.getFont1());
		
		panels[2].setBounds(35, 441, 315, 45);
		panels[2].add(passwordfields[0]);
		
		frame.add(panels[2]);
		
		//anmeldebutton
		buttons[0].setOpaque(false);
		buttons[0].setContentAreaFilled(false);
		buttons[0].setBorderPainted(false);
		
		panels[3].setBounds(120, 500, 145, 45);
		panels[3].add(buttons[0]);
		
		frame.add(panels[3]);
		
		//hintergrundsebene
		labels[0].setBounds(0, 0, 385, 761);
		
		URL image_url = Main.class.getResource("/textures/background/login.png");
		
		BufferedImage image = null;
		try {
			image = ImageIO.read(image_url);
		} catch (IOException e) {
		    e.printStackTrace();
		}
		
		Image scaled_image = image.getScaledInstance(labels[0].getWidth(), labels[0].getHeight(), Image.SCALE_REPLICATE);
		
		ImageIcon bgimage = new ImageIcon(scaled_image);
		
		labels[0].setIcon(bgimage);
		
		frame.add(labels[0]);
		
		
		frame.setVisible(true);
		
		textfields[0].addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				passwordfields[0].requestFocus(); //fokus wird auf das passwortfeld gesetzt
			}
		});
		
		passwordfields[0].addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				buttons[0].doClick(); //bei passworteingabe wird ein klick ausgeführt
			}
		});
		
		buttons[0].addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				
				if (Offline.getOfflineMode() == true) { //wenn offline modus aktiviert wird, sind keine benutzerdaten erforderlich
					frame_class.setFramePosition(frame.getLocation()); 
					frame.setVisible(false);
					
					System.out.println("anmeldung erfolgreich im offline modus (benutzerdaten unrelevant)");
					
					try {
						new Start();
					} catch (IOException e2) {}
				} else { //im falle das der offline-modus nicht ausgewählt wird, wird mit der datenbank gearbeitet
					
					//anmelden
					User currentUser = new User(textfields[0].getText(), passwordfields[0].getText(), 0); //klassen import von klasse "User" und seiner Variablen
					
					System.out.println("online modus wurde ausgewählt");
					
					
					if (dao.getUser(currentUser) == true) {
						
						/*
						 * benutzername und passwort ist richtig, login wird durchgeführt
						 */
						
						System.out.println("benutzerdaten sind richtig, anmeldevorgang wird durchgeführt");
						
						frame_class.setFramePosition(frame.getLocation());
						
						frame.setVisible(false);
						
						try {
							new Start();
						} catch (IOException e2) {}
						
					} else {
						
						/*
						 * passwort ist falsch, login wird abgebrochen
						 */
						
						System.out.println("benutzerdaten sind falsch, anmeldevorgang wird abgebrochen");
						
						
						textfields[0].setBackground(Color.RED);
						passwordfields[0].setBackground(Color.RED);

						textfields[0].requestFocus();
						
					}
					/*
					 * Was in beiden Fällen passiert
					 */
					passwordfields[0].setText("");
					textfields[0].setText("");
				}
			}
		});
	}
}
