package datenbank;

import java.sql.*;

import com.mysql.cj.jdbc.MysqlDataSource;

public class OracleDsSingleton {
	
	private static OracleDsSingleton dss = null;
	private static MysqlDataSource ds = null;
	
	//login
	private OracleDsSingleton(){
		ds = new MysqlDataSource();
		
		ds.setURL("");
		ds.setUser("");
		ds.setPassword("");
	}
	
	public static OracleDsSingleton getInstance() {
		if(dss == null) dss = new OracleDsSingleton();
		return dss;
	}
	
	public Connection getConnection() throws SQLException{
		Connection con = null;
		con = ds.getConnection();
		return con;
	}
}
